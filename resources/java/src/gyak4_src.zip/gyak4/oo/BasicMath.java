package gyak4.oo;

import java.io.Console;

public class BasicMath {
	public static void main(final String[] args) {
		final Console console = System.console();
		String line = null;
		
		while ( ! (line = console.readLine()).isEmpty() ) {
			try {
				final double alpha = Double.parseDouble( line );
				
				System.out.println("sin(" + alpha + ") = " + Math.sin(alpha) );
				System.out.println("cos(" + alpha + ") = " + Math.cos(alpha) );
				System.out.println("tan(" + alpha + ") = " + Math.tan(alpha) );
			} catch (final NumberFormatException e) {
				System.err.println("Cannot parse as double:" + line);
			}
		}
		
		System.out.println("Byez!");
	}
}
