package gyak4.oo;

import java.io.Console;

public class Reverse {
	public static void main(final String[] args) {
		final Console console = System.console();
		String line = null;
		
		while ( ! (line = console.readLine()).isEmpty() ) {
			final StringBuilder sb = new StringBuilder(line);
			sb.reverse();
			System.out.println( sb );
		}
		
		System.out.println("Byez!");
	}
}
