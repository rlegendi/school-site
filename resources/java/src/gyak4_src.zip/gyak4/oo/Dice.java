package gyak4.oo;

import java.io.Console;
import java.util.Random;

public class Dice {
	private static final Random rnd = new Random();
	
	private static int k6() {
		return rnd.nextInt(6) + 1; // [0..5] --> [1..6]
	}
	
	public static void main(final String[] args) {
		final Console console = System.console();
		String line = null;
		
		while ( ! (line = console.readLine()).isEmpty() ) {
			try {
				final int n = Integer.parseInt( line );
				
				for (int i=0; i<n; ++i) {
					System.out.println( (i+1) + ". k6 = " + k6() );
				}
			} catch (final NumberFormatException e) {
				System.err.println("Cannot parse as int:" + line);
			}
		}
		
		System.out.println("Byez!");
	}
}
