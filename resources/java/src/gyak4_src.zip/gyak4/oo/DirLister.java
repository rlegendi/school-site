package gyak4.oo;

import java.io.File;

public class DirLister {
	private static final String SUFFIX = ".java";

	public static void main(final String[] args) {
		if ( args.length != 1 ) {
			System.err.println("A programnak 1 parameter kell!");
			System.exit(1);
		}
		
		final File dir = new File(args[0]);
		
		if ( ! dir.isDirectory() ) {
			System.err.println("Nem konyvtar: " + dir.getAbsolutePath());
			System.exit(2);
		}
		
		for (final String act : dir.list()) {
			if ( act.endsWith(SUFFIX) ) {
				System.out.println(act);
			}
		}
	}
}
