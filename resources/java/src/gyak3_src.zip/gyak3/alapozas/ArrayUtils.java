package gyak3.alapozas;

import java.util.Arrays;

/**
 * Harmadik gyakorlat tombos feladatai.
 * 
 * <p> Az osztaly kizarolag <code>double[]</code> tipusu tombokkel foglalkozik. Gyakorlaskepp javallott ezen fuggvenyek
 * <code>int[]</code> tipusu tombokkel dolgozo valtozatainak analog implementacioja! </p>
 * 
 * @author rlegendi
 */
public class ArrayUtils {
	
	/**
	 * <b>1. feladat:</b> Kiszamolja a parameterkent megadott tomb elemeinek osszeget.
	 * 
	 * @param arr egy <code>double</code> tomb, amit osszegezni szeretnenk
	 * @return a parameterkent megadott tomb elemeinek osszege
	 */
	public static double sum(final double[] arr) {
		double ret = 0.0;
		
		for (final double act : arr) {
			ret += act;
		}
		
		return ret;
	}
	
	/**
	 * <b>2. feladat:</b> Kiszamolja a parameterkent megadott tomb elemeinek atlagat.
	 * 
	 * @param arr egy <code>double</code> tomb, amit atlagolni szeretnenk
	 * @return a parameterkent megadott tomb elemeinek atlaga
	 */
	public static double avg(final double[] arr) {
		return sum(arr) / arr.length;
	}
	
	/**
	 * <b>3. feladat:</b> Normalizalja a megadott tomb elemeit (minden elemet leoszt a teljes tomb osszegevel).
	 * 
	 * <p> Ne feledjuk, hogy referencian keresztul erjuk el a tomb elemeit, igy azok <b>megvaltoztathatok</b> (v.o. ertek
	 * szerinti parameteratadas)! Maga a referencia is ertek szerint adodik at, igy magahoz a tombhoz tartozo referenciat
	 * megvaltoztatni nem tudjuk! A gepi szamabrazolas miatt az eredmeny elosen torzitott lesz (a teljes osszeg nem
	 * feltetlen lesz <code>1.0</code>)! </p>
	 * 
	 * @param arr egy <code>double</code> tomb, amit normalni szeretnenk
	 */
	public static void norm(final double[] arr) {
		final double sum = sum(arr);
		
		for (int i=0; i<arr.length; ++i) {
			arr[i] /= sum; // arr[i] = arr[i] / sum
		}
	}
	
	/**
	 * <b>4. feladat:</b> Tomb rendezese.
	 * 
	 * <p> A gyakorlat targya, hogy megtanuljatok kezelni a <a href="http://download.oracle.com/javase/6/docs/api/">Java
	 * referenciat</a>. Ezt a feladatot megoldhatjatok ugy is, ha kezzel implementaltok egy tetszoleges rendezo algoritmust,
	 * de en ezt a megoldast szorgalmaznam. </p> 
	 * 
	 * @param arr egy <code>double</code> tomb, amit rendezni szeretnenk
	 */
	public static void sort(final double[] arr) {
		Arrays.sort(arr);
	}
	
	/**
	 * <b>5. feladat:</b> Tomb minimalis es maximalis elemenek meghatarozasa.
	 * 
	 * <p> Elsokent lerendezzuk a tombot, majd kihasznalva a rendezettseget konstans idoben meg tudjuk hatarozni a minimalis
	 * es maximalis elemeket (ertsd: az elso es az utolso elemet). A fuggveny visszaad egy tombot, amelynek elso eleme a
	 * minimalis, masodik eleme pedig a maximalis elem. </p>
	 * 
	 * @param arr egy <code>double</code> tomb, aminek szeretnenk meghatarozni a minimalis es maximalis elemeit
	 * @return a parameterkent megadott tomb minimalis es maximalis elemei egy tombben
	 */
	public static double[] minMax(final double[] arr) {
		sort(arr);
		
		final double min = arr[0];
		final double max = arr[ arr.length - 1 ];
		
		return new double[] { min, max };
	}
	
	/**
	 * <b>6. feladat:</b> Stringek osszefuzese a megadott elvalaszto karakter segitsegevel. A fuggveny tetszoleges szamu
	 * parameterrel meghivhato.
	 * 
	 * @param separator az elvalaszto karakter
	 * @param params az osszefuzni kivant karakterlancok
	 * @return a parameterkent megadott karakterlancok egyetlen <code>String</code> objektumban, a megadott separator
	 * 		   karakterrel elvalasztva
	 */
	public static String join(final char separator, final String... params) { // params tombkent kezelheto, ld. gyakorlat!
		String ret = "";
		
		for (int i=0; i<params.length; ++i) {
			if (i>0) ret += separator; // elvalaszto karakter konkatenalasa
			ret += params[i];          // parameterek konkatenalasa
		}
		
		return ret;
	}
	
	/**
	 * <b>7. feladat:</b> Az elozo feladat <i>tulterhelt</i> valtozata, amely a szokoz {@literal ' '} karakterrel fuzi ossze
	 * a parameterkent megadott karakterlancokat.
	 * 
	 * @param params az osszefuzni kivant karakterlancok
	 * @return a parameterkent megadott karakterlancok egyetlen <code>String</code> objektumban, a {@literal ' '} separator
	 * 		   karakterrel elvalasztva
	 */
	public static String join(final String... params) {
		return join(' ', params);
	}
	
	/**
	 * <b>8. feladat:</b> Ket azonos dimenzioszamu vektor skalaris szorzatanak meghatarozasa. 
	 * 
	 * @param u elso vektor
	 * @param v masodik vektor
	 * @return a ket vektor skalaris szorzata
	 */
	public static double dotProduct(final double[] u, final double[] v) {
		if (u.length != v.length) {
			throw new IllegalArgumentException("Hibas parameterek: u es v dimenziojanak egyeznie kell! " +
					"dim(u) = " + u.length + " != dim(v) = " + v.length);
		}
		
		double ret = 0.0;
		
		for (int i=0; i<u.length; ++i) {
			ret += u[i] * v[i];
		}
		
		return ret;
	}
	
	/** A kodolashoz hasznalt egyedi konstans. Az {@literal 'Z'} betu :-) */
	private static final char XOR_CONST = 'Z';
	
	/**
	 * <b>9. feladat:</b> Kodolo fuggveny, amely a parameterkent megadott <code>char[]</code> tombot karakterenkent XOR
	 * operatorral kodolja.
	 * 
	 * @param arr egy <code>char[]</code> tomb, amit szeretnenk karakterenkent kodolni 
	 */
	public static void cipher(final char[] arr) {
		for (int i=0; i<arr.length; ++i) {
			arr[i] ^= XOR_CONST; // arr[i] = arr[i] ^ XOR_CONST;
		}
	}
	
	/**
	 * <b>10. feladat:</b> Dekodolo fuggveny az elozo feladathoz. Kihasznaljuk az operator azon tulajdonsagat, miszerint:
	 * 
	 * <pre>
	 * A ^ B ^ B = A
	 * </pre>
	 * 
	 * @param arr
	 * @see <a href="http://en.wikipedia.org/wiki/XOR_cipher">XOR kodolas</a>
	 */
	public static void decipher(final char[] arr) {
		for (int i=0; i<arr.length; ++i) {
			arr[i] ^= XOR_CONST; // arr[i] = arr[i] ^ XOR_CONST;
		}
	}
	
	/**
	 * Peldafuttatasok.
	 */
	public static void main(final String[] args) {
		final double[] ds = { 3.0, 1.0, 2.0 };
		
		System.out.println( sum( ds ) );
		
		System.out.println( avg( ds ) );
		
		norm( ds );
		System.out.println( Arrays.toString( ds ) );
		
		sort( ds );
		System.out.println( Arrays.toString( ds ) );
		
		System.out.println( Arrays.toString( minMax( ds ) ) );
		
		System.out.println( join(',', "Cartman", "Kenny", "Kyle", "Stan") );
		
		System.out.println( join("All", "your", "base", "are", "belong", "to", "us") );
		
		final double[] u = { 1.0, 3.0, -5.0 };
		final double[] v = { 4.0, -2.0, -1.0 };
		
		System.out.println( dotProduct(u, v) );
		
		final char[] charArr = "THE TECHNOVIKING DOESN'T DANCE TO THE MUSIC! THE MUSIC DANCES TO THE TECHNOVIKING!".toCharArray();
		
		cipher( charArr );
		System.out.println( new String(charArr) );
		
		decipher(charArr);
		System.out.println( new String(charArr) );
	}
}
