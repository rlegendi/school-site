package gyak3.alapozas;

/**
 * Harmadik gyakorlat tobbdimenzios karakterlancos feladatai.
 * 
 * @author rlegendi
 */
public class StringUtils {
	
	/**
	 * <b>1. feladat:</b> Nagybetuk kisbetusse alakitasa, es a szamok kivetelevel minden mas karakter lecserelese egy
	 * {@literal '_'} karakterrel. 
	 * 
	 * @param str a feldolgozando karakterlanc
	 * @return a feladat szovegenek megfeleloen modositott karakterlanc
	 */
	public static String transformNonAlphanum(final String str) {
		final char[] carr = str.toCharArray();
		
		for (int i=0; i<carr.length; ++i) {
			if ( Character.isLetter( carr[i] )) {
				carr[i] = Character.toLowerCase(carr[i]);
			} else if ( ! Character.isDigit( carr[i]) ) {
				carr[i] = '_';
			}
		}
		
		return new String(carr);
	}
	
	/** Magyar specialis karakterek. */
	private static final String special = "������������������";
	
	/** Helyettesito karakterek. */
	private static final String simple  = "aeiuuuoooAEIUUUOOO";
	
	/**
	 * <b>2. feladat:</b> Ekezetes karaktereket lecsereli azok ekezet nelkuli valtozatara.
	 * 
	 * @param str a feldolgozando karakterlanc
	 * @return a feladat szovegenek megfeleloen modositott karakterlanc
	 */
	public static String transformHun(final String str) {
		String ret = "";
		
		for (final char ch : str.toCharArray()) {
			final int idx = special.indexOf(ch);
			
			if ( idx > -1 ) {
				ret += simple.charAt(idx);
			} else {
				ret += ch;
			}
		}
		
		return ret;
	}
	
	/**
	 * <b>3. feladat:</b> A parmeterkent megadott karakterlanc elso karakteret nagybetusse alakitja. 
	 * 
	 * @param str a feldolgozando karakterlanc
	 * @return a feladat szovegenek megfeleloen modositott karakterlanc
	 */
	public static String capitalize(final String param) {
		if ( 0 == param.length() ) {
			return "";
		}
		
		return ( Character.toUpperCase( param.charAt( 0 ) ) + param.substring( 1 ) );
	}
	
	/**
	 * <b>4. feladat:</b> A parmeterkent megadott karakterlanc elso karakteret kisbetusse alakitja. 
	 * 
	 * @param str a feldolgozando karakterlanc
	 * @return a feladat szovegenek megfeleloen modositott karakterlanc
	 */
	public static String decapitalize(final String param) {
		if ( 0 == param.length() ) {
			return "";
		}
		
		return ( Character.toLowerCase( param.charAt( 0 ) ) + param.substring( 1 ) );
	}
	
	/**
	 * <b>5. feladat:</b> A parameterkent megadott elso karakterlancra vizsgalja meg, hogy a masodik parameterkent megadott
	 * <code>prefix</code> karakterlanccal kezdodik-e.
	 * 
	 * @param string az elemzett karakterlanc
	 * @param prefix az illeszteni kivant <i>prefix</i> sorozat
	 * @return <code>true</code> ertek, amennyiben a <code>prefix</code> illesztheto;
	 * 				<code>false</code> egyebkent
	 */
	public static boolean startsWith(final String string, final String prefix) {
		return string.toLowerCase().startsWith( prefix.toLowerCase() );
	}
	
	/**
	 * Peldafuttatasok.
	 */
	public static void main(final String[] args) {
		System.out.println( transformNonAlphanum("Xabc (123-456)") );
		
		System.out.println( transformHun("�rv�zt�r� �tvef�r�g�p") );
		System.out.println( transformHun("�RV�ZT�R� �TVEF�R�G�P") );
		
		System.out.println( capitalize("rosszul kezdodo mondat. Talan.") );
		
		System.out.println( decapitalize("Szegedi") );
		
		System.out.println( startsWith("Windows 7", "win") );
	}
}
