package gyak3.alapozas;

/**
 * Harmadik gyakorlat tobbdimenzios tombos feladatai.
 * 
 * <p> Az osztaly kizarolag <code>double[]</code> tipusu tombokkel foglalkozik. Gyakorlaskepp javallott ezen fuggvenyek
 * <code>int[]</code> tipusu tombokkel dolgozo valtozatainak analog implementacioja! </p>
 * 
 * @author rlegendi
 */
public class MultiDimArrayUtils {
	
	/** Sorvege jel (ld. az oldalamon az ide vonatkozo FAQ bejegyzest!) */
	public static final String EOL = System.getProperty("line.separator");
	
	/**
	 * <b>1. feladat:</b> Matrixkent reprezental egy ketdimenzios tombot a visszaadott karakterlanc. 
	 * 
	 * @param arr a tomb, amit szeretnenk matrix-szeru karakterlanckent latni
	 * @return a megadott tomb matrix-szeru karakterlanca
	 */
	public static String asMatrix(final double[][] arr) {
		String ret = "";
		
		for (int i=0; i<arr.length; ++i) {
			for (int j=0; j<arr[i].length; ++j) {
				if (j>0) ret += " ";
				ret += arr[i][j];
			}
			
			ret += EOL;
		}
		
		return ret;
	}
	
	/**
	 * <b>2. feladat:</b> A megadott ketdimenzios tomb sorainak, oszlopainak, es foatlojaban levo elemek osszeget irja ki. 
	 * 
	 * @param arr az elemezni kivant <code>double[]</code> tomb
	 */
	public static void sumLines(final double[][] arr) {
		// Matrix negyzetessegenek ellenorzese
		for (int i=0, n = arr.length; i<n; ++i) {
			if (n != arr[i].length) {
				throw new IllegalArgumentException("Nem negyzetes matrix! n=" + n + ", " + ( i + 1 ) + ". m=" + arr[i].length);
			}
		}
		
		// Sorok kiirasa es sorosszegek meghatarozasa
		for (int i=0; i<arr.length; ++i) {
			double rowSum = 0.0;
			
			for (int j=0; j<arr[i].length; ++j) {
				if (j>0) System.out.print(' ');
				rowSum += arr[i][j];
				System.out.print(arr[i][j]);
			}
			
			System.out.println(" | " + rowSum);
		}
		
		// Oszloposszegek es utolso dekoralo sor kiirasa
		String colLine = "";
		for (int i=0; i<arr.length; ++i) {
			if (i>0) colLine += " ";
			double colSum = 0.0;
			for (int j=0; j<arr[i].length; ++j) {
				colSum += arr[j][i];
			}
			colLine += colSum;
		}
		
		System.out.println( colLine.replaceAll(".", "-") + "-/"); // Minden karakter lecserelese
		
		// Diagonalis elemek osszegenek meghatarozasa
		double diagSum = 0.0;
		
		for (int i=0; i<arr.length; ++i) {
			diagSum += arr[i][i];
		}
		
		colLine += "   " + diagSum;

		System.out.println( colLine );
		System.out.println();
	}
	
	/**
	 * <b>3. feladat:</b> A megadott ketdimenzios tombkent reprezentalt matrix beszorzasa a megadott <i>lambda</i> valos
	 * ertekkel.
	 * 
	 * @param arr a tombkent reprezentalt matrix
	 * @param lambda a szorzashoz hasznalt valos ertek
	 */
	public static void mul(final double[][] arr, final double lambda) {
		for (int i=0; i<arr.length; ++i) {
			for (int j=0; j<arr.length; ++j) {
				arr[i][j] *= lambda;
			}
		}
	}
	
	/**
	 * <b>4. feladat:</b> Matrixok osszeadasa. Csak azonos meretu matrixokra mukodik (elvileg). A parameterkent kapott
	 * matrixok erteket nem valtoztatja.
	 * 
	 * @param a az elso matrix
	 * @param b a masodik matrix
	 * @return az <code>a</code> es <code>b</code> matrixok osszege
	 */
	public static double[][] add(final double[][] a, final double[][] b) {
		// Matrix-meretek ellenorzese
		if (a.length != b.length || 0 == a.length || 0 == b.length) {
			throw new IllegalArgumentException("Nem megfelelo meretu matrixok!");
		}
		
		for (int i=0, n = a[0].length; i<n; ++i) {
			if (n != a[i].length || n != b[i].length) {
				throw new IllegalArgumentException("Nem megfelelo meretu matrixok!");
			}
		}
		
		// Osszeadas
		final double[][] ret = new double[a.length][a[0].length];
		
		for (int i=0; i<a.length; ++i) {
			for (int j=0; j<a[i].length; ++j) {
				ret[i][j] = a[i][j] + b[i][j];
			}
		}
		
		return ret;
	}
	
	/**
	 * <b>5. feladat:</b> Matrixok osszeszorzasa. A parameterek ellenorzese meglehetosen korulmenyes, tulsagosan elvonna a
	 * figyelmet a megvalositasrol. Erosen ajanlott gyakorlaskent elkesziteni. A parameterkent kapott matrixok erteket nem
	 * valtoztatja meg a fuggveny.
	 * 
	 * @param a elso matrix
	 * @param b masodik matrix
	 * @return az <code>a</code> es <code>b</code> matrixok szorzata
	 */
	public static double[][] mul(final double[][] a, final double[][] b) {
		// Parameterek ellenorzese: HF
		
		// Szorzas
		final double[][] ret = new double[a.length][a.length];
		
		for (int i=0; i<a.length; ++i) {
			for (int j=0; j<a.length; ++j) {
				for (int k=0; k<a[i].length; ++k) {
					ret[i][j] += a[i][k] * b[k][j];
				}
			}
		}
		
		return ret;
	}
	
	/**
	 * Peldafuttatasok.
	 */
	public static void main(final String[] args) {
		final double[][] mdarr = new double[3][3];
		mdarr[1][1] = 1.0;
		System.out.println( asMatrix( mdarr ) );
		
		final double[][] arr = {
				{ 0.0, 1.0, 2.0 },
				{ 1.0, 2.0, 3.0 },
				{ 2.0, 3.0, 4.0 }
		};
		
		sumLines( arr );
		
		mul(arr, 0.5);
		System.out.println( asMatrix( arr ) );
		
		final double[][] brr = {
				{ 2.0, 1.5, 1.0 },
				{ 1.5, 1.0, 0.5 },
				{ 1.0, 0.5, 0.0 }
		};
		
		System.out.println( asMatrix( add( arr, brr ) ) );
		
		final double[][] n1 = { { 0, -1, 2 },
							   { 4, 11, 2 } };
		
		final double[][] m1 = { { 3, -1 },
							   { 1, 2 },
							   { 6, 1 } };
		
		System.out.println( asMatrix( mul( n1, m1) ) );
		

		final double[][] n2 = { { 1, 2 },
						   		{ 3, 4 },
						   		{ 5, 6 } };
		
		final double[][] m2 = { { 1, 2, 3 },
   								{ 4, 5, 6 } };
		
		System.out.println( asMatrix( mul( n2, m2) ) );

	}
	
}
