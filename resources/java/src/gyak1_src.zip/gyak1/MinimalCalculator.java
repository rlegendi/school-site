package gyak1;

public class MinimalCalculator {
	public static void main(final String[] args) {
		if (args.length != 3) {
			System.err.println("A programnak 3 parameter kell!");
			System.exit(1);
		}
		
		final int operator = Integer.parseInt(args[0]);
		final double lhs = Double.parseDouble(args[1]);
		final double rhs = Double.parseDouble(args[2]);
		
		double result = 0.0;
		
		switch (operator) {
		case 1:
			result = lhs + rhs;
			break;
			
		case 2:
			result = lhs - rhs;
			break;
			
		case 3:
			result = lhs * rhs;
			break;
			
		case 4:
			result = lhs / rhs;
			break;
			
		default:
			System.err.println("Nem ertelmezett muvelet: " + operator);
			System.exit(2);
			break;
		}
		
		System.out.println("Az eredmeny: " + result);
	}
}
