package gyak1;

public class PerfectNumbers1 {
	public static boolean isPerfectNumber(final int num) {
		int sum = 0;

		for (int i = 1; i < num; ++i) {
			if (0 == num % i) {
				sum += i; // sum = sum + i;
			}
		}

		return (num == sum);
	}

	public static void main(final String[] args) {
		if (args.length != 1) {
			System.err.println("A programnak 1 parameter kell!");
			System.exit(1);
		}

		final int value = Integer.parseInt(args[0]);

		if ( isPerfectNumber(value) ) {
			System.out.println("A(z) " + value + " tokeletes szam.");
		} else {
			System.out.println("A(z) " + value + " nem tokeletes szam.");
		}
	}
}
