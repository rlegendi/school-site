package gyak1;

public class Converter {
	public static void main(final String[] args) {
		if (args.length != 2) {
			System.err.println("A programnak pontosan 2 parameterre van szuksege!");
			System.exit(1);
		}

		final int task = Integer.parseInt(args[0]);
		final double value = Double.parseDouble(args[1]);

		// Az osztasnal figyeljunk: az operatorok visszateresi ertekenek tipusa a bovebb tipusu
		// argumentum tipusa. Igy 1 / 2 == 0 az implicit integer cast miatt ((int) 0.5 == 0).

		// Ilyenkor vagy explicit jeloljuk, hogy double literalt hasznalunk (1.0), vagy hasznaljuk a
		// double cast operatort: (double) var

		switch (task) {
		case 0: {
			final double result = (9.0 / 5.0) * value + 32;
			System.out.println(value + "C == " + result + "F");
			break;
		}

		case 1: {
			final double result = (5.0 / 9.0) * (value - 32.0);
			System.out.println(value + "F == " + result + "C");
			break;
		}

		default: {
			System.err.println("Hibas input: " + task);
			System.exit(2);
		}
		}
	}
}
