package gyak2;

@SuppressWarnings("serial") // Ezzel a sorral nem kell foglalkozni
class DiscriminantNegativeException extends Exception {
	// Sajat konstruktor, amely a kivetelhez szoveget tud rendelni
	public DiscriminantNegativeException(final String message) {
		super(message);
	}
}

public class SqRoots {
	private static double[] sqroots(final int a, final int b, final int c) throws DiscriminantNegativeException {
		if (0 == a) {
			throw new IllegalArgumentException("A 'a' parameter nem lehet 0!");
		}

		final double D = b * b - 4 * a * c;
		
		if ( D < 0 ) {
			throw new DiscriminantNegativeException("A masodfoku egyenletnek nincsenek valos gyokei!");
		}
		
		if ( 0 == D ) {
			return new double[] {
				( -b + Math.sqrt(D) ) / ( 2 * a )
			};
		}
		
		return new double[] {
			( -b - Math.sqrt(D) ) / ( 2 * a ),
			( -b + Math.sqrt(D) ) / ( 2 * a )
		};
	}

	public static void main(final String[] args) {
		try {
			final int a = Integer.parseInt(args[0]);
			final int b = Integer.parseInt(args[1]);
			final int c = Integer.parseInt(args[2]);
			
			final double[] result = sqroots(a, b, c);
			
			System.out.println("Az egyenlet megoldasai:");
			System.out.println("-----------------------");
			
			for (int i=0; i<result.length; ++i) {
				if (i>0) System.out.print(", ");
				System.out.print(result[i]);
			}
			
			System.out.println();
		} catch (final ArrayIndexOutOfBoundsException e) {
			System.err.println("Hiba: nem megfelelo parameterszam.");
			
		} catch (final NumberFormatException e) {
			System.err.println("Hiba: nem szam input. " + e.getMessage());
			
		} catch (final Exception e) {
			System.err.println("Hiba: " + e.getMessage() + ".");
			
		} catch (final Throwable t) {
			System.err.println("Egyeb, nem vart hiba.");
			t.printStackTrace();
		}
	}
}
