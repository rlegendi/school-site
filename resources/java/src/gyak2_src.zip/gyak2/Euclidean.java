package gyak2;

public class Euclidean {
	
	// public --> ld. Numbers.java ;], lusta voltam, na
	public static int gcd(int a, int b) {
		if ( 0 == a ) {
			return b;
		}
		
		while ( b != 0 ) {
			if ( a > b ) {
				a -= b;
			} else {
				b -= a;
			}
		}
		
		return a;
	}
	
	public static void main(final String[] args) {
		assert ( 21 == gcd(105, 252) &&
				 21 == gcd(105, 147) );
		
		System.out.println( gcd(105, 252) );
		System.out.println( gcd(105, 147) );
	}

}
