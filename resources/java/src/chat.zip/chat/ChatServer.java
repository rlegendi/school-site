package chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

class ClientHandler
		extends Thread {
	private static final ArrayList<ClientHandler> handlers = new ArrayList<ClientHandler>();
	
	private final long ID;
	private final Socket socket;
	private final BufferedReader in;
	private final PrintWriter out;
	
	public ClientHandler(final long ID, final Socket socket)
			throws IOException {
		this.socket = socket;
		this.ID = ID;
		
		this.in = new BufferedReader( new InputStreamReader( socket.getInputStream() ) );
		this.out = new PrintWriter( new OutputStreamWriter( socket.getOutputStream() ) );
		
		synchronized ( handlers ) {
			broadcastMessage( "Client joined " + ID + " chat." );
			handlers.add( this ); // Nehogy az iteracional gond legyen belole
		}
	}
	
	@Override
	public void run() {
		try {
			String line = null;
			while ( ( line = in.readLine() ) != null ) {
				broadcastMessage( line );
			}
		} catch (final IOException e) {
			e.printStackTrace();
		} finally {
			try {
				socket.close();
			} catch (final IOException e) {
				e.printStackTrace();
			} finally {
				synchronized ( handlers ) { // Nehogy az iteracional gond legyen belole
					handlers.remove( this );
					broadcastMessage( "Client " + ID + " left chat." );
				}
			}
		}
	}
	
	private void broadcastMessage(final String message) {
		synchronized ( handlers ) {
			for (final ClientHandler act : handlers) { // Tobbiek ertesitese
				if ( ! act.equals( this ) ) {
					act.out.println( "[Guest" + ID + "] " + message );
					act.out.flush();
				}
			}
		}
	}
	
	@Override
	public int hashCode() {
		return 31 + (int) ( ID ^ ( ID >>> 32 ) );
	}
	
	@Override
	public boolean equals(final Object obj) {
		if ( obj instanceof ClientHandler ) {
			final ClientHandler other = (ClientHandler) obj;
			return ID == other.ID;
		}
		
		return false;
	}
}

public class ChatServer {
	public static final int PORT = 2442;
	
	public static void main(final String[] args) {
		try (ServerSocket socket = new ServerSocket( PORT )) {
			long ctr = 0;
			System.out.println( "Server active, listening..." );
			while ( true ) {
				final ClientHandler handler = new ClientHandler( ctr++, socket.accept() );
				handler.start();
				
				System.out.println( "New handler initiated: " + handler );
			}
		} catch (final IOException e) {
			e.printStackTrace();
		}
	}
}
