package chat;

import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

class ConsoleReader
		extends Thread {
	private final BufferedReader in;
	
	public ConsoleReader(final Socket socket)
			throws IOException {
		this.in = new BufferedReader( new InputStreamReader( socket.getInputStream() ) );
	}
	
	@Override
	public void run() {
		try {
			String line = null;
			while ( ( line = in.readLine() ) != null ) {
				System.out.println( line );
			}
		} catch (final IOException e) {
			e.printStackTrace();
		}
	}
}

class ConsoleWriter
		extends Thread {
	private final PrintWriter out;
	
	public ConsoleWriter(final Socket socket)
			throws IOException {
		this.out = new PrintWriter( new OutputStreamWriter( socket.getOutputStream() ) );
	}
	
	@Override
	public void run() {
		final Console console = System.console();
		String line = null;
		
		while ( ( line = console.readLine() ) != null ) {
			System.out.println("Read line: " + line);
			out.println( line );
			out.flush();
			System.out.println("Flushed line...");
		}
	}
}

public class ChatClient {
	private final ConsoleReader reader;
	private final ConsoleWriter writer;
	
	public ChatClient(final Socket socket)
			throws IOException {
		reader = new ConsoleReader( socket );
		writer = new ConsoleWriter( socket );
	}
	
	public void begin()
			throws InterruptedException {
		reader.start();
		writer.start();
		
		reader.join();
		writer.join();
	}
	
	public static void main(final String[] args) {
		try (Socket socket = new Socket( "localhost", ChatServer.PORT )) {
			final ChatClient client = new ChatClient( socket );
			client.begin();
		} catch (final IOException | InterruptedException e) {
			e.printStackTrace();
		}
	}
}
