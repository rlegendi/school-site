package gyak5.f1.data;

public class Point2D extends APoint implements IFrissitheto {
	protected double y;
	
	public Point2D(final double x, final double y) {
		super(x);
		
		this.y = y;
	}
	
	public double getY() {
		return y;
	}

	public void setY(final double y) {
		this.y = y;
	}

	@Override
	public void translate(final double... coordinates) {
		x += coordinates[0];
		y += coordinates[1];
	}

	@Override
	public void rotate(double alpha) {
		alpha %= 360; // alpha = alpha % 360;
		
		final double newx = x * Math.cos(alpha) - y * Math.sin(alpha);
		final double newy = x * Math.sin(alpha) + y * Math.cos(alpha);
		
		x = newx;
		y = newy;
	}

	@Override
	public void reflect() {
		x = -x;
		y = -y;
	}
	
	@Override
	public void frissit() {
		x = Double.parseDouble( console.readLine() );
		y = Double.parseDouble( console.readLine() );
	}
	
	@Override
	public String toString() {
		return "[x=" + x + ", y=" + y + "]";
	}
}
