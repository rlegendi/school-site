package gyak5.f1.data;

import java.io.Console;

public interface IFrissitheto {
	public static final Console console = System.console();
	public void frissit();
}
