package gyak5.f1.data;

public class Point1D extends APoint implements IKirajzolhato, IFrissitheto {
	public Point1D(final double x) {
		super(x);
	}
	
	@Override
	public void translate(final double... coordinates) {
		x += coordinates[0];
	}

	@Override
	public void rotate(double alpha) {
		alpha %= 360; // alpha = alpha % 360;
		
		if (90 < alpha && alpha <= 270) {
			x = -x;
		}
	}

	@Override
	public void reflect() {
		x = -x;
	}
	
	@Override
	public void kirajzol() {
		if (x < 0) {
			for (int i=0; i<(int)x; ++i) {
				System.out.print(' ');
			}
		} else {
			for (int i=-(int)x; i<0; ++i) {
				System.out.print(' ');
			}
		}
		
		System.out.println("#");
	}
	
	@Override
	public void frissit() {
		x = Double.parseDouble( console.readLine() );
	}
	
	@Override
	public String toString() {
		return "[x=" + x + "]";
	}
}
