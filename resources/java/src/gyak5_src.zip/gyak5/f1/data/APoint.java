package gyak5.f1.data;

public abstract class APoint {
	
	/**
	 * Minden pontnak van legalabb egy koordinataja, az ide is kiemelheto.
	 * Protected, hogy lathato legyen a leszarmazottakban.
	 */
	protected double x;
	
	/**
	 * Protected konstruktor, <b>csak</b> a leszarmazottakbol es a csomagbol hivhato!
	 * Amugy sem peldanyosithato, mert absztrakt, de igy explicit jelezzuk is a szandekunkat. 
	 */
	protected APoint(final double x) {
		this.x = x;
	}
	
	public double getX() {
		return x;
	}
	
	public void setX(double x) {
		this.x = x;
	}
	
	public abstract void translate(double... coordinates);
	public abstract void rotate(double alpha);
	public abstract void reflect();
}
