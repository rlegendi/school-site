package gyak5.f1.data;

public interface IKirajzolhato {
	// Minden tagfuggveny alapbol public abstract, de erdemes kiirni, ugy nem okoz zavart
	public abstract void kirajzol();
}
