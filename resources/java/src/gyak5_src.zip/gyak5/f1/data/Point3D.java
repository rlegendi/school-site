package gyak5.f1.data;

public class Point3D extends APoint implements IFrissitheto {
	protected double y, z;
	
	public Point3D(final double x, final double y, final double z) {
		super(x);
		
		this.y = y;
		this.z = z;
	}
	
	public double getY() {
		return y;
	}

	public void setY(final double y) {
		this.y = y;
	}

	public double getZ() {
		return z;
	}

	public void setZ(final double z) {
		this.z = z;
	}

	@Override
	public void translate(final double... coordinates) {
		x += coordinates[0];
		y += coordinates[1];
		z += coordinates[2];
	}

	@Override
	public void rotate(double alpha) { // x tengely korul, 
		alpha %= 360; // alpha = alpha % 360;
		
		final double newx = x;
		final double newy = y * Math.cos(alpha) - z * Math.sin(alpha);
		final double newz = y * Math.sin(alpha) + z * Math.cos(alpha);
		
		x = newx;
		y = newy;
		z = newz;
	}

	@Override
	public void reflect() {
		x = -x;
		y = -y;
		z = -z;
	}
	
	@Override
	public void frissit() {
		x = Double.parseDouble( console.readLine() );
		y = Double.parseDouble( console.readLine() );
		z = Double.parseDouble( console.readLine() );
	}
	
	@Override
	public String toString() {
		return "[x=" + x + ", y=" + y + ", z=" + z + "]";
	}
}
