package gyak5.f1;

import gyak5.f1.data.APoint;
import gyak5.f1.data.IFrissitheto;
import gyak5.f1.data.IKirajzolhato;
import gyak5.f1.data.Point1D;
import gyak5.f1.data.Point2D;
import gyak5.f1.data.Point3D;

public class Main {
	public static void main(final String[] args) {
		pointTest( new Point1D(0.0) );
		pointTest( new Point2D(0.0, 0.0) );
		pointTest( new Point3D(0.0, 0.0, 0.0) );
	}

	private static void pointTest(final APoint p) {
		System.out.println(p);
		
		p.translate(1.0, 1.0, 1.0); // Csak ha van ertelme
		System.out.println(p);
		
		p.rotate(180);
		System.out.println(p);
		
		p.reflect();
		System.out.println(p);
		
		if (p instanceof IFrissitheto) {
			final IFrissitheto frissitheto = (IFrissitheto) p;
			frissitheto.frissit();
			System.out.println(frissitheto);
		}
		
		if (p instanceof IKirajzolhato) {
			final IKirajzolhato kirajzolhato = (IKirajzolhato) p;
			kirajzolhato.kirajzol();
		}
	}
}
