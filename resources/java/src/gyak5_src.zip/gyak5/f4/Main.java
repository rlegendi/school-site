package gyak5.f4;

import gyak5.f4.data.Matrix;

public class Main {
	public static void main(final String[] args) {
        final Matrix D = new Matrix( new double[][] { { 1, 2, 3 }, { 4, 5, 6 }, { 9, 1, 3} });
        System.out.println(D);

        D.transpose();
        System.out.println(D);
        
        D.mul( 2 );
        System.out.println(D);

        D.add( new Matrix(3) );
        System.out.println(D);

        final Matrix identity = new Matrix( new double[][] { { 1, 0, 0 }, { 0, 1, 0 }, { 0, 0, 1} } );

        D.add( identity );
        System.out.println(D);

        D.mul(identity);
        System.out.println(D);

        System.out.println( D.hashCode() );
        System.out.println( D.equals( identity ) );
        System.out.println( identity.equals( identity ) );
	}
}
