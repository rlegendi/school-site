package gyak5.f4.data;

import java.util.Arrays;

public class Matrix {
	
	// ======================================================================================================================
	// === 4. Feladat =======================================================================================================
	
	private double[][] arr;

	public Matrix(final int n) {
		this( new double[n][n] ); // alapbol minden elem 0 lesz
	}
	
	public Matrix(final double[][] arr) {
		if (arr.length > 0) { // Kesztyus tombok ellenorzese
			final int M = arr[0].length;
			for (int i=1; i<arr.length; ++i) {
				if (M != arr[i].length) {
					throw new IllegalArgumentException("Nem matrix! " + Arrays.toString(arr));
				}
			}
			
		}
		
		this.arr = arr;
	}
	
	public int N() {
		return arr.length;
	}
	
	public int M() {
		return ( N() > 0 ) ? arr[0].length : 0;
	}
	
	public boolean isSymmetric() {
		return ( N() == M() );
	}
	
	public void mul(final double lambda) {
		for (int i=0; i<N(); ++i) {
			for (int j=0; j<M(); ++j) {
				arr[i][j] *= lambda;
			}
		}
	}
	
	private boolean sameSizeAs(final Matrix rhs) {
		return ( N() == rhs.N() && M() == rhs.M() );
	}

	public void add(final Matrix rhs) {
		if ( ! sameSizeAs(rhs) ) {
			throw new IllegalArgumentException("Cannot add matrices " + this + " and " + rhs + ".");
		}
		
		for (int i=0; i<N(); ++i) {
			for (int j=0; j<M(); ++j) {
				arr[i][j] += rhs.arr[i][j];
			}
		}
	}

	// ======================================================================================================================
	// === 5. Feladat =======================================================================================================
	
	@Override
	public int hashCode() {
		return Arrays.hashCode(arr);
	}

	@Override
	public boolean equals(final Object obj) {
		if ( obj instanceof Matrix) {
			final Matrix other = (Matrix) obj;
			if ( ! sameSizeAs(other) ) {
				return false;
			}
			
			for (int i=0; i<N(); ++i) {
				for (int j=0; j<M(); ++j) {
					if ( arr[i][j] != other.arr[i][j] ) {
						return false;
					}
				}
			}
			
			return true;
		}
		
		return false;
	}

	/** Sorvege jel (ld. az oldalamon az ide vonatkozo FAQ bejegyzest!) */
	public static final String EOL = System.getProperty("line.separator");
	
	@Override
	public String toString() {
		String ret = "";
		
		for (int i=0; i<arr.length; ++i) {
			for (int j=0; j<arr[i].length; ++j) {
				if (j>0) ret += " ";
				ret += arr[i][j];
			}
			
			ret += EOL;
		}
		
		return ret;
	}
	
	// ======================================================================================================================
	// === 6. feladat =======================================================================================================
	
	public void transpose() {
		for (int i=0; i<N(); ++i) {
			for (int j=0; j<i; ++j) {
				swap(i, j);
			}
		}
	}
	
	private void swap(int i, int j) {
		double tmp = arr[i][j];
		arr[i][j] = arr[j][i];
		arr[j][i] = tmp;
	}
	
	public double trace() {
		if ( ! isSymmetric() ) {
			throw new IllegalStateException("No trace for non-symmetric matrices.");
		}
		
		double ret = 0.0;
		
		for (int i=0; i<N(); ++i) {
			ret += arr[i][i];
		}
		
		return ret;
	}
	
	public void mul(final Matrix rhs) {
		if (N() != rhs.M() && M() != rhs.N()) {
			throw new IllegalArgumentException("Cannot multiply matrices " + this + " and " + rhs + ".");
		}
		
		final double[][] newArr = new double[M()][N()];
		
		for (int i=0; i<M(); ++i) {
			for (int j=0; j<N(); ++j) {
				for (int k=0; k<N(); ++k) {
					newArr[i][j] += arr[i][k] * rhs.arr[k][j];
				}
			}
		}
		
		this.arr = newArr;
	}
}
