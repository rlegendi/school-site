package gyak5.f3;

import gyak5.f3.data.ASorozat;
import gyak5.f3.data.Arithmetic;
import gyak5.f3.data.Geometric;
import gyak5.f3.data.Util;

public class Main {
	private static void testSequence(ASorozat sequence) {
		System.out.println(sequence);
		System.out.println("S(10) = " + sequence.S(10));
		System.out.println("Monoton increasing? " + sequence.isMonotonicIncreasing());
		System.out.println("Monoton decreasing? " + sequence.isMonotonicDecreasing());
		System.out.println("-------------------------------------------------------");
	}

	public static void main(String[] args) {
		testSequence(new Arithmetic(0, 1));
		testSequence(new Arithmetic(0, 2));
		testSequence(new Arithmetic(1, 0));
		testSequence(new Arithmetic(1, 2));
		testSequence(new Arithmetic(101, -20));
		testSequence(new Arithmetic(-2.1, -1.01));
		
		testSequence(new Geometric(1, 2));
		testSequence(new Geometric(3, 3));
		testSequence(new Geometric(7, 10));
		
		testSequence( Util.beolvas() );
	}
}
