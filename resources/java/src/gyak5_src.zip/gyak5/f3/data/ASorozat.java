package gyak5.f3.data;

public abstract class ASorozat {
	public ASorozat() {
		;
	}
	
	public abstract double[] members(int n);
	
	/**
	 * Jelenleg ezt nem hasznalja egyetlen megvalositas sem, mert vannak explicit kepletek a reszsorozat-osszegek
	 * meghatarozasara. Ugyanakkor altalanosan megadhato ebben a formaban, ha nincs ra explicit megoldas.
	 */
	public double S(final int n) {
		final double[] seq = members(n); // a konkret megvalositastol fugg a visszaadott ertek
		double ret = 0.0;
		
		for (final double act : seq) {
			ret += act;
		}
		
		return ret;
	}
	
	public abstract boolean isMonotonicIncreasing();
	public abstract boolean isMonotonicDecreasing();
}
