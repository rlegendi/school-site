package gyak5.f3.data;

public class Geometric extends ASorozat {
	private final double a;
	private final double q;
	
	public Geometric(final double a, final double q) {
		super();
		
		this.a = a;
		this.q = q;
	}

	@Override
	public double[] members(final int n) {
		final double[] ret = new double[n];
		
		for (int i=0; i<n; ++i) {
			ret[i] = a * Math.pow(q, i);
		}
		
		return ret;
	}

	@Override
	public double S(final int n) {
		return a * ( Math.pow( q, n ) - 1.0 ) / ( q - 1.0 ); 
	}

	@Override
	public boolean isMonotonicIncreasing() {
		return ( 1.0 <= q );
	}

	@Override
	public boolean isMonotonicDecreasing() {
		return ( 0.0 <= q && q <= 1.0 );
	}
	
	@Override
	public String toString() {
		String ret = "(a=" + a + ", q=" + q + ") ";
		final double[] members = members(10);
		
		for (int i=0; i<members.length; ++i) {
			if (i>0) ret += ", ";
			ret += members[i];
		}
		
		ret += ", ...";
		return ret;
	}

}
