package gyak5.f3.data;

import java.io.Console;

public final class Util {
	
	private static final Console console = System.console();
	
	public static ASorozat beolvas() {
		System.out.println("1 - Arithmetic");
		System.out.println("2 - Geometric");
		System.out.println("--------------");
		System.out.println("Choice? ");
		
		final int choice = Integer.parseInt( console.readLine() );
		
		switch (choice) {
			case 1: {
				final int a = Integer.parseInt( console.readLine("a? ") );
				final int d = Integer.parseInt( console.readLine("d? ") );
				return new Arithmetic(a, d);
			}
			case 2: {
				final int a = Integer.parseInt( console.readLine("a? ") );
				final int q = Integer.parseInt( console.readLine("q? ") );
				return new Geometric(a, q);
			}
		}
		
		throw new IllegalStateException("Cannot create any sequence.");
	}
	
	private Util() {
		;
	}
}
