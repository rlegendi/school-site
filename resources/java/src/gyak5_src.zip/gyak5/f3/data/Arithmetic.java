package gyak5.f3.data;

public class Arithmetic extends ASorozat {
	private double a;
	private double d;
	
	public Arithmetic(final double a, final double d) {
		super();
		
		this.a = a;
		this.d = d;
	}

	@Override
	public double[] members(final int n) {
		final double[] ret = new double[n];
		
		for (int i=0; i<n; ++i) {
			ret[i] = a + i * d;
		}
		
		return ret;
	}

	@Override
	public double S(final int n) {
		return ( 2.0 * a + ( n - 1 ) * d ) * n / 2.0;
	}

	@Override
	public boolean isMonotonicIncreasing() {
		return ( 0 <= d );
	}

	@Override
	public boolean isMonotonicDecreasing() {
		return ( d <= 0 );
	}
	
	@Override
	public String toString() {
		String ret = "(a=" + a + ", d=" + d + ") ";
		final double[] members = members(10);
		
		for (int i=0; i<members.length; ++i) {
			if (i>0) ret += ", ";
			ret += members[i];
		}
		
		ret += ", ...";
		return ret;
	}
	
}
