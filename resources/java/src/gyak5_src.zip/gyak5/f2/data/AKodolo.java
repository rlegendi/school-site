package gyak5.f2.data;

public abstract class AKodolo {
	public abstract String kodol(final String eredeti);
	public abstract String dekodol(final String kodolt);
	
	public static String prepocess(final String text) {
		return text.toUpperCase();
	}
}
