package gyak5.f2.data;

public class Monoalphabetic extends AKodolo {
	private static final String PLAIN  = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static final String CIPHER = "ZEBRASCDFGHIJKLMNOPQTUVWXY";

	private String transform(final String from, final String to, final String eredeti) {
		String ret = "";
		
		for (final char act : eredeti.toCharArray()) {
			final int idx = from.indexOf(act);
			
			ret += ( idx > -1 )
						? to.charAt(idx)
						: ' ';
		}
		
		return ret;
	}

	@Override
	public String kodol(String eredeti) {
		eredeti = prepocess(eredeti);
		return transform(PLAIN, CIPHER, eredeti);
	}

	@Override
	public String dekodol(String kodolt) {
		kodolt = prepocess(kodolt);
		return transform(CIPHER, PLAIN, kodolt);
	}
	
}
