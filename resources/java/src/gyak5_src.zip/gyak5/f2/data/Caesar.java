package gyak5.f2.data;

public class Caesar extends AKodolo {

	@Override
	public String kodol(String eredeti) {
		eredeti = prepocess(eredeti);
		String ret = "";
		
		for (final char act : eredeti.toCharArray()) {
			char next = ' ';
			
			// Csak a betuket csereljuk, minden mast kitorlunk, szokoz lesz belole
			if ( 'A' <= act && act < 'X' ) {
				next = (char) (act + 3);
			} else {
				switch (act) {
				case 'X':
					next = 'A';
					break;
				case 'Y':
					next = 'B';
					break;
				case 'Z':
					next = 'C';
				}
			}
			
			ret += next;
		}
		
		return ret;
	}

	@Override
	public String dekodol(String kodolt) {
		kodolt = prepocess(kodolt);
		String ret = "";
		
		for (final char act : kodolt.toCharArray()) {
			char next = ' ';
			
			// Csak a betuket csereljuk, minden mast kitorlunk, szokoz lesz belole
			if ( 'C' < act && act <= 'X' ) {
				next = (char) (act - 3);
			} else {
				switch (act) {
				case 'A':
					next = 'X';
					break;
				case 'B':
					next = 'Y';
					break;
				case 'C':
					next = 'Z';
				}
			}
			
			ret += next;
		}
		
		return ret;
	}
	
}
