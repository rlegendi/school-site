package gyak5.f2;

import gyak5.f2.data.AKodolo;
import gyak5.f2.data.Caesar;
import gyak5.f2.data.Monoalphabetic;

public class Main {
	private static void testCipher(final AKodolo kodolo, String text) {
		text = AKodolo.prepocess(text);
		final String cipher = kodolo.kodol(text);
		System.out.println( "Plaintext:  " + text);
		System.out.println( "Ciphertext: " + cipher );
		
		if ( ! text.equals( kodolo.dekodol(cipher) ) ) {
			throw new IllegalStateException("Nem bijektiv lekepezes!");
		}
	}
	
	public static void main(final String[] args) {
		testCipher( new Caesar(), "JULIUS CAESAR" );
		testCipher( new Monoalphabetic(), "FLEE AT ONCE WE ARE DISCOVERED" );
	}
}
