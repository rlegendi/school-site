package wumpus.gameobjects;

import wumpus.GameObject;

public class Wumpus
		extends GameObject {
	
	public Wumpus() {
		super( 'W' );
	}
	
	@Override
	public boolean isSmelly() {
		return true;
	}
	
}
