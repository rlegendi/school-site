package wumpus;

public class GameObject {
	
	private final char display;
	private Position position;
	
	public GameObject(final char display) {
		this.display = display;
	}
	
	public Position getPosition() {
		return position;
	}
	
	public void setPosition(final Position position) {
		this.position = position;
	}
	
	public char getDisplay() {
		return display;
	}
	
	public boolean isNextTo(final GameObject rhs) {
		return position.equals( rhs.getPosition() );
	}
	
	public boolean isSmelly() {
		return false;
	}
	
	public boolean isBreezy() {
		return false;
	}
	
	public boolean isGloomy() {
		return false;
	}
	
}
