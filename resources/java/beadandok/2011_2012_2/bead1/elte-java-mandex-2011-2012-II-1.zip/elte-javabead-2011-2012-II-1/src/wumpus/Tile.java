package wumpus;

import java.util.ArrayList;
import java.util.List;

public class Tile {
	private final List<GameObject> objectsAt = new ArrayList<GameObject>();
	
	public boolean isEmpty() {
		return objectsAt.isEmpty();
	}
	
	public void removeObject(final GameObject obj) {
		assert ( objectsAt.contains( obj ) );
		objectsAt.remove( obj );
	}
	
	public void addObject(final GameObject obj) {
		objectsAt.add( obj );
	}
	
	public boolean hasBreezyObject() {
		for (final GameObject act : objectsAt) {
			if ( act.isBreezy() ) {
				return true;
			}
		}
		
		return false;
	}
	
	public boolean hasSmellyObject() {
		for (final GameObject act : objectsAt) {
			if ( act.isSmelly() ) {
				return true;
			}
		}
		
		return false;
	}
	
	public boolean hasGloomyObject() {
		for (final GameObject act : objectsAt) {
			if ( act.isGloomy() ) {
				return true;
			}
		}
		
		return false;
	}
	
	public char getDisplay() {
		if ( isEmpty() ) {
			return '.';
		}
		
		// Wumpus, Pit, Treasure: all shadows the Player, but that's ok for now 
		return objectsAt.get( 0 ).getDisplay();
	}
	
}
