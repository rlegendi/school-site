package wumpus;

import static wumpus.Constants.N;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Utils {
	private static Random random = new Random();
	
	public static int rnd(int max) {
		return random.nextInt( max );
	}
	
	public static List<Position> randomLocationSample(final int k) {
		final List<Position> ret = new ArrayList<Position>( k );
		final List<Position> all = new ArrayList<Position>( N * N );
		for (int i = 0; i < N; ++i) {
			for (int j = 0; j < N; ++j) {
				all.add( new Position( i, j ) );
			}
		}
		
		for (int i = 0; i < k; ++i) {
			final int idx = Utils.rnd( all.size() );
			ret.add( all.remove( idx ) );
		}
		
		return ret;
	}
	

}
