package wumpus;

import static wumpus.Constants.N;

import java.util.HashSet;
import java.util.Set;

public class Position {
	private final int x, y;
	
	public Position(final int x, final int y) {
		super();
		this.x = x;
		this.y = y;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public Set<Position> getNeighborhood() {
		final Set<Position> ret = new HashSet<Position>();
		
		checkAndAddPos( ret, x + 1, y );
		checkAndAddPos( ret, x, y + 1 );
		checkAndAddPos( ret, x - 1, y );
		checkAndAddPos( ret, x, y - 1 );
		
		return ret;
	}
	
	private void checkAndAddPos(final Set<Position> ret, final int x, final int y) {
		final Position pos = new Position( x, y );
		if ( pos.isValid() ) {
			ret.add( pos );
		}
	}
	
	private boolean isValid() {
		return 0 <= x && x < N && 0 <= y && y < N;
	}
	
	public Position randomize() {
		final int xdiff = Utils.rnd( 3 ) - 1; // -1, 0, 1
		final int ydiff = Utils.rnd( 3 ) - 1; // -1, 0, 1
		
		final Position newPos = new Position( x + xdiff, y + ydiff );
		if ( newPos.isValid() ) {
			return newPos;
		}
		
		return this;
	}
	
	public Position shift(final Direction direction) {
		int x = this.x;
		int y = this.y;
		
		switch ( direction ) {
			case NORTH:
				x--;
				break;
			
			case SOUTH:
				x++;
				break;
			
			case EAST:
				y++;
				break;
			
			case WEST:
				y--;
				break;
			
			default:
				break;
		}
		
		final Position newPos = new Position( x, y );
		if ( newPos.isValid() ) {
			return newPos;
		}
		
		return this;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + x;
		result = prime * result + y;
		return result;
	}
	
	@Override
	public boolean equals(final Object obj) {
		if ( this == obj )
			return true;
		if ( obj == null )
			return false;
		if ( getClass() != obj.getClass() )
			return false;
		final Position other = (Position) obj;
		if ( x != other.x )
			return false;
		if ( y != other.y )
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "[x=" + x + ", y=" + y + "]";
	}
	
}
