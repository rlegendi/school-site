package wumpus;

public class Perception {
	private final boolean breezy, smelly, gloomy, edgeOfTheWorld;
	
	public Perception(final boolean edgeOfTheWorld, final boolean breezy, final boolean smelly, final boolean gloomy) {
		super();
		this.edgeOfTheWorld = edgeOfTheWorld;
		this.breezy = breezy;
		this.smelly = smelly;
		this.gloomy = gloomy;
	}
	
	public boolean isBreezy() {
		return breezy;
	}
	
	public boolean isSmelly() {
		return smelly;
	}
	
	public boolean isGloomy() {
		return gloomy;
	}
	
	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		
		if ( edgeOfTheWorld ) {
			sb.append( "You are at the edge of the world." );
			sb.append( Constants.EOL );
		}
		
		sb.append( "Perception: " );
		sb.append( ( breezy ) ? "breezy" : "-" ).append( ", " );
		sb.append( ( smelly ) ? "smelly" : "-" ).append( ", " );
		sb.append( ( gloomy ) ? "gloomy" : "-" );
		
		return sb.toString();
	}
}
