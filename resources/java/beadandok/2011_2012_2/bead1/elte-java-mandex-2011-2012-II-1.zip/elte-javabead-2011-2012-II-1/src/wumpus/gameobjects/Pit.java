package wumpus.gameobjects;

import wumpus.GameObject;

public class Pit
		extends GameObject {
	public Pit() {
		super( 'P' );
	}
	
	@Override
	public boolean isBreezy() {
		return true;
	}
}
