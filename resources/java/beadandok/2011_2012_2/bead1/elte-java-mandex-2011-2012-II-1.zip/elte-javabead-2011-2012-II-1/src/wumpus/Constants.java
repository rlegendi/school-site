package wumpus;

public final class Constants {
	public static final String EOL = System.getProperty( "line.separator" );
	public static final int N = 5;
}
