package wumpus.gameobjects;

import wumpus.GameObject;

public class Treasure
		extends GameObject {
	
	public Treasure() {
		super( 'T' );
	}
	
	@Override
	public boolean isGloomy() {
		return true;
	}
	
}
