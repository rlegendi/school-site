package wumpus;

import static wumpus.Constants.N;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import wumpus.gameobjects.Pit;
import wumpus.gameobjects.Player;
import wumpus.gameobjects.Treasure;
import wumpus.gameobjects.Wumpus;

public class World {
	private final Tile[][] world;
	private final Player player;
	private final Wumpus wumpus;
	private final Treasure treasure;
	private final List<Pit> pits = new ArrayList<Pit>();
	
	public World(final Position playerPosition, final Position wumpusPosition, final Position treasurePosition,
			final List<Position> pitPositions) {
		world = new Tile[N][N];
		
		for (int i = 0; i < N; ++i) {
			for (int j = 0; j < N; ++j) {
				world[i][j] = new Tile();
			}
		}
		
		player = new Player();
		wumpus = new Wumpus();
		treasure = new Treasure();
		
		addToPosition( player, playerPosition );
		addToPosition( wumpus, wumpusPosition );
		addToPosition( treasure, treasurePosition );
		
		for (final Position pos : pitPositions) {
			final Pit pit = new Pit();
			pits.add( pit );
			addToPosition( pit, pos );
		}
	}
	
	public static World createRandomWorld(final int pits) {
		final List<Position> locs = Utils.randomLocationSample( 3 + pits );
		return new World( locs.get( 0 ), locs.get( 1 ), locs.get( 2 ), locs.subList( 3, locs.size() ) );
	}
	
	private void addToPosition(final GameObject obj, final Position pos) {
		final int x = pos.getX();
		final int y = pos.getY();
		
		assert ( world[x][y].isEmpty() );
		world[x][y].addObject( obj );
		obj.setPosition( new Position( x, y ) );
	}
	
	public void movePlayer(final Direction direction) {
		move( player, player.getPosition().shift( direction ) );
	}
	
	public void moveWumpus() {
		move( wumpus, wumpus.getPosition().randomize() );
	}
	
	private void move(final GameObject obj, final Position toPos) {
		final Position pos = obj.getPosition();
		tileAt( pos ).removeObject( obj );
		tileAt( toPos ).addObject( obj );
		obj.setPosition( toPos );
	}
	
	public boolean hasWumpusFoundPlayer() {
		return wumpus.isNextTo( player );
	}
	
	public boolean hasPlayerFoundTreasure() {
		return player.isNextTo( treasure );
	}
	
	public boolean hasPlayerFellIntoPit() {
		for (final Pit pit : pits) {
			if ( player.isNextTo( pit ) ) {
				return true;
			}
		}
		
		return false;
	}
	
	public Perception playerPerception() {
		final Set<Position> neigh = player.getPosition().getNeighborhood();
		return new Perception( playerAtEdge(), anyPitAt( neigh ), wumpusAt( neigh ), treasureAt( neigh ) );
	}
	
	private boolean playerAtEdge() {
		return 0 == player.getPosition().getX() || 0 == player.getPosition().getY() ||
				N - 1 == player.getPosition().getX() || N - 1 == player.getPosition().getY();
	}
	
	private boolean treasureAt(final Set<Position> neigh) {
		for (final Position act : neigh) {
			if ( tileAt( act ).hasGloomyObject() ) {
				return true;
			}
		}
		
		return false;
	}
	
	private boolean anyPitAt(final Set<Position> neigh) {
		for (final Position act : neigh) {
			if ( tileAt( act ).hasBreezyObject() ) {
				return true;
			}
		}
		
		return false;
	}
	
	private Tile tileAt(final Position act) {
		return world[act.getX()][act.getY()];
	}
	
	private boolean wumpusAt(final Set<Position> neigh) {
		for (final Position act : neigh) {
			if ( tileAt( act ).hasSmellyObject() ) {
				return true;
			}
		}
		
		return false;
	}
	
	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		
		for (int i = 0; i < N; ++i) {
			if ( i > 0 ) {
				sb.append( Constants.EOL );
			}
			
			for (int j = 0; j < N; ++j) {
				sb.append( world[i][j].getDisplay() );
			}
		}
		
		return sb.toString();
	}
	
}
