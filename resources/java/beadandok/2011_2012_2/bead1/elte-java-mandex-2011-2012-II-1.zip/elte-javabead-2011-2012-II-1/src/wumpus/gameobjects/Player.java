package wumpus.gameobjects;

import wumpus.GameObject;

public class Player
		extends GameObject {
	
	public Player() {
		super( '@' );
	}
	
}
