package wumpus;

import java.io.Console;

public class Game {
	private static final int defaultPitNumber = 3;
	private final World world;
	
	public Game() {
		world = World.createRandomWorld( defaultPitNumber );
	}
	
	public void executeCommand(final String command) {
		switch ( command ) {
			case "cheat":
				System.out.println( world );
				break;
			case "n":
				movePlayer( Direction.NORTH );
				break;
			case "s":
				movePlayer( Direction.SOUTH );
				break;
			case "e":
				movePlayer( Direction.EAST );
				break;
			case "w":
				movePlayer( Direction.WEST );
				break;
		}
	}
	
	private void movePlayer(final Direction direction) {
		world.movePlayer( direction );
		world.moveWumpus();
	}
	
	public void showPerception() {
		System.out.println( world.playerPerception() );
	}
	
	private boolean hasPlayerFoundTreasure() {
		return world.hasPlayerFoundTreasure();
	}
	
	public boolean hasWumpusFoundPlayer() {
		return world.hasWumpusFoundPlayer();
	}
	
	private boolean hasPlayerFellIntoPit() {
		return world.hasPlayerFellIntoPit();
	}
	
	public static void main(final String[] args) {
		final Game game = new Game();
		
		final Console con = System.console();
		String command = null;
		
		System.out.println( "=== Welcome to the Wumpus Lair ===" );
		game.showPerception();
		
		while ( ! ( command = con.readLine( "Which direction to go? " ) ).equals( "exit" ) ) {
			game.executeCommand( command );
			
			if ( game.hasPlayerFoundTreasure() ) {
				System.out.println( "Congratulations! You have found the treasure!" );
				break;
			}
			
			if ( game.hasWumpusFoundPlayer() ) {
				System.out.println( "Game over! The Wumpus devoured you!" );
				break;
			}
			
			if ( game.hasPlayerFellIntoPit() ) {
				System.out.println( "Game over! You fell into a pit!" );
				break;
			}
			
			System.out.println();
			game.showPerception();
		}
	}
	
}
