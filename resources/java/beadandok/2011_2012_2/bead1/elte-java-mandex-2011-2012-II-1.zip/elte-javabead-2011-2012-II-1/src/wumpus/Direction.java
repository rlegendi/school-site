package wumpus;

public enum Direction {
	NORTH, SOUTH, EAST, WEST;
}
