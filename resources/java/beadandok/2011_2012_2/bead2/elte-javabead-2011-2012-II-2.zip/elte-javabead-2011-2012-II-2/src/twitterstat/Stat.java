package twitterstat;

public class Stat {
	private final String user, picUrl;
	private final int wordCount;
	
	public Stat(final String user, final String picUrl, final int wordCount) {
		super();
		this.user = user;
		this.picUrl = picUrl;
		this.wordCount = wordCount;
	}
	
	public String getUser() {
		return user;
	}
	
	public String getPicUrl() {
		return picUrl;
	}
	
	public int getWordCount() {
		return wordCount;
	}
	
	@Override
	public String toString() {
		return "Stat [user=" + user + ", wordCount=" + wordCount + "]";
	}
}
