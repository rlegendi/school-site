package twitterstat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Client {
	public static void main(final String[] args) {
		try (final Socket socket = new Socket( "localhost", Server.PORT );
				final PrintWriter pw = new PrintWriter( socket.getOutputStream() );
				final BufferedReader br = new BufferedReader( new InputStreamReader( System.in ) )) {
			
			while ( true ) {
				final String command = br.readLine();
				
				if ( command.startsWith( "script" ) ) {
					executeScript( pw, command );
				} else {
					pw.println( command );
				}
				
				pw.flush();
				
				if ( command.equals( "exit" ) ) {
					break;
				}
			}
		} catch (final IOException e) {
			throw new IllegalStateException( e );
		}
	}
	
	private static void executeScript(final PrintWriter pw, final String command)
			throws IOException {
		final String script = command.substring( "script".length() ).trim();
		final List<String> scriptCommands = Files.readAllLines( Paths.get( script ), Charset.defaultCharset() );
		
		for (final String act : scriptCommands) {
			pw.println( act );
			pw.flush();
		}
	}
}
