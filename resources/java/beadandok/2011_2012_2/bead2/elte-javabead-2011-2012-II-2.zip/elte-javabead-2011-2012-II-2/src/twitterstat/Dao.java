package twitterstat;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class Dao {
	static {
		System.setProperty( "derby.system.home", "db" );
	}
	
	private static final Logger logger = Logger.getLogger( Dao.class.getName() );
	private static final String connectionString = "jdbc:derby:TweetDB;user=me;password=mine";
	private static final String initConnectionString = connectionString + ";create=true";
	
	private final Connection dbConnection;
	
	private Dao(final String conn)
			throws SQLException {
		dbConnection = DriverManager.getConnection( conn );
	}
	
	public static Dao daoForExistingDB()
			throws SQLException {
		return new Dao( connectionString );
	}
	
	public static Dao daoForFreshlyInitializedDb()
			throws SQLException {
		final Dao dao = new Dao( initConnectionString );
		dao.initDb();
		return dao;
	}
	
	public void initDb() {
		logger.info( "Initializing DB..." );
		
		final String createTweets = "CREATE TABLE Tweets (id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY, name VARCHAR(50), pic VARCHAR(500), status VARCHAR(160))";
		exec( createTweets );
		
		logger.info( "DB initialized" );
	}
	
	private void exec(final String command) {
		try (Statement statement = dbConnection.createStatement()) {
			statement.execute( command );
		} catch (final SQLException e) {
			throw new IllegalStateException( e );
		}
	}
	
	public void addTweet(final String userName, final String picUrl, final String status) {
		logger.info( "Adding tweet of " + userName + "[" + picUrl + "]: " + status );
		
		final String insertSql = "INSERT INTO Tweets (name, pic, status) VALUES(?,?, ?)";
		
		try (PreparedStatement st = dbConnection.prepareStatement( insertSql )) {
			
			st.setString( 1, userName );
			st.setString( 2, picUrl );
			st.setString( 3, status );
			
			final int res = st.executeUpdate();
			
			logger.info( res + " rows affected by insertion." );
		} catch (final SQLException e) {
			throw new IllegalStateException( e );
		}
	}
	
	public List<Stat> createStats() {
		logger.info( "Creating statistics..." );
		final ArrayList<Stat> ret = new ArrayList<Stat>();
		
		try (Statement st = dbConnection.createStatement()) {
			final String selectString = "SELECT name, pic, SUM(LENGTH(status)) FROM Tweets GROUP BY name, pic";
			
			final ResultSet rs = st.executeQuery( selectString );
			
			while ( rs.next() ) {
				final Stat stat = new Stat( rs.getString( 1 ), rs.getString( 2 ), rs.getInt( 3 ) );
				logger.info( "Returning: " + stat );
				ret.add( stat );
			}
		} catch (final SQLException e) {
			throw new IllegalStateException( e );
		}
		
		return ret;
	}
	
}
