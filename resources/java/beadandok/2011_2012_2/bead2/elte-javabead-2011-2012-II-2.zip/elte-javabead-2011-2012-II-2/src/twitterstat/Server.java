package twitterstat;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Server {
	public static final int PORT = 80;
	private final Dao dao;
	
	public Server(final Dao dao) {
		this.dao = dao;
	}
	
	public static void main(final String[] args)
			throws SQLException {
		final Dao dao = createDao( args );
		
		final Server server = new Server( dao );
		server.start();
	}
	
	private static Dao createDao(final String[] args)
			throws SQLException {
		if ( args.length > 0 ) {
			switch ( args[0] ) {
				case "-init":
					return Dao.daoForFreshlyInitializedDb();
				default:
					throw new IllegalArgumentException( "Unknown parameter: " + args[0] );
			}
		}
		
		return Dao.daoForExistingDB();
	}
	
	public void start() {
		try (final ServerSocket server = new ServerSocket( PORT )) {
			Socket client = server.accept();
			final BufferedReader br = new BufferedReader( new InputStreamReader( client.getInputStream() ) );
			
			while ( true ) {
				final String line = br.readLine();
				System.out.println( "Got message: " + line );
				
				if ( line.equals( "exit" ) ) {
					client.close();
					return;
				}
				
				if ( line.equals( "stats" ) ) {
					createStats();
					continue;
				}
				
				processUsers( line );
			}
		} catch (final IOException e) {
			throw new IllegalStateException( e );
		}
	}
	
	private void processUsers(final String line) {
		final String[] userNames = line.split( "," );
		
		for (final String user : userNames) {
			parseDataFor( user );
		}
	}
	
	private void parseDataFor(final String userName) {
		try (BufferedReader br = new BufferedReader( new InputStreamReader( new URL( "http://twitter.com/statuses/user_timeline.xml?id=" +
				userName ).openStream() ) )) {
			final ArrayList<String> texts = new ArrayList<String>();
			String picUrl = null;
			
			String line = null;
			while ( ( line = br.readLine() ) != null ) {
				line = line.trim();
				
				if ( null == picUrl && line.startsWith( "<profile_image_url>" ) ) {
					picUrl = line.replaceAll( "<profile_image_url>", "" ).replaceAll( "</profile_image_url>", "" ).trim();
				}
				
				if ( line.startsWith( "<text>" ) ) {
					final String status = line.replaceAll( "<text>", "" ).replaceAll( "</text>", "" ).trim();
					texts.add( status );
				}
			}
			
			for (final String status : texts) {
				dao.addTweet( userName, picUrl, status );
			}
		} catch (final IOException e) {
			throw new IllegalStateException( e );
		}
	}
	
	private void createStats() {
		final List<Stat> stats = dao.createStats();
		saveStats( stats );
	}
	
	private void saveStats(final List<Stat> stats) {
		try (PrintWriter pw = new PrintWriter( "index.html" )) {
			pw.println( "<html>" );
			pw.println( "<body>" );
			pw.println( "<table border='1'>" );
			pw.println( "	<tr>" );
			pw.println( "		<th>Picture</th>" );
			pw.println( "		<th>Id</th>" );
			pw.println( "		<th>Char Count</th>" );
			pw.println( "	</tr>" );
			pw.println();
			
			for (final Stat stat : stats) {
				pw.println( "	<tr>" );
				pw.println( "		<td><img src='" + stat.getPicUrl() + "'/></td>" );
				pw.println( "		<td>" + stat.getUser() + "</td>" );
				pw.println( "		<td>" + stat.getWordCount() + "</td>" );
				pw.println( "	</tr>" );
				pw.println();
			}
			
			pw.println( "</table>" );
			pw.println( "</body>" );
			pw.println( "</html>" );
		} catch (final FileNotFoundException e) {
			throw new IllegalStateException( e );
		}
	}
}
