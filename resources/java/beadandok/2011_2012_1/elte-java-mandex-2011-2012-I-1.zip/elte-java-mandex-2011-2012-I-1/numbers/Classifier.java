package numbers;

import java.util.Arrays;

import numbers.common.Utils;

public class Classifier {
	public static boolean isPerfect(final int number) {
		return new Classifier( number ).isPerfect();
	}
	
	private final int number;
	private final int[] factors;
	private final int sigma;
	
	public Classifier(final int number) {
		super();
		this.number = number;
		
		factors = initFactors();
		sigma = Utils.sum( factors );
	}
	
	private int[] initFactors() {
		// Accumulate factors
		final StringBuffer csv = new StringBuffer();
		
		for (int i = 1; i <= number; ++i) {
			if ( isFactor( i ) ) {
				if ( csv.length() != 0 ) {
					csv.append( "," );
				}
				
				csv.append( i );
			}
		}
		
		// Convert to an integer array
		final String[] stringFactors = csv.toString().split( "," );
		final int[] ret = new int[stringFactors.length];
		
		for (int i = 0; i < stringFactors.length; ++i) {
			ret[i] = Integer.parseInt( stringFactors[i] );
		}
		
		return ret;
	}
	
	public int getNumber() {
		return number;
	}
	
	public int numberOfFactors() {
		return factors.length;
	}
	
	public boolean isFactor(final int factor) {
		return 0 == number % factor;
	}
	
	// Return a copy of the stored array
	public int[] getFactors() {
		return Arrays.copyOf( factors, factors.length );
	}
	
	public boolean isPerfect() {
		return sigma == 2 * number;
	}
	
	public boolean isDeficient() {
		return sigma < 2 * number;
	}
	
	public boolean isAbundant() {
		return sigma > 2 * number;
	}
	
}
