package numbers.common;

public class Utils {
	public static int sum(final int[] arr) {
		int ret = 0;
		
		for (final int i : arr) {
			ret += i;
		}
		
		return ret;
	}
}
