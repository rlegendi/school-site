# Programozási nyelvek (Java) #
**2011-2012-1, 1. Beadandó feladat**

* **Kiírás időpontja:** 2011. október 14. (*hivatalosan*)
* **Beadási határidő:** 2011. október 21. (*ZH-t megelőző hét, péntek*), 23:00
* *Amennyiben bármi kérdés merül fel a feladattal kapcsolatban, a gyakorlatvezetők e-mailben segítenek.*

## A feladat leírása ##

Készítsünk el egy osztályozó implementációt (`numbers.Classifier`)! Ennek egyetlen konstruktora legyen, amely egy pozitív egész számot vár
paraméterként (*ezt ellenőrizni nem szükséges*).

A megvalósítandó osztály feladata, hogy az adott szám pozitív osztóinak meghatározása alapján három csoportba sorolja a számokat.
Legyen `sigma(n)` az `n` szám osztóinak összege (az `1`-et, önmagát beleértve), ekkor az `n` számot a következőképp osztályozzuk: 

* *tökéletes szám*, ha `sigma(n) == 2n`
* *hiányos szám*, ha `sigma(n) < 2n`
* *bővelkedő szám*, ha `sigma(n) > 2n`

## Tecnhikai részletek ##

* Szükség van egy egyszerű statikus `int sum(int[] arr)` segédfüggvényre, amelyet a `numbers.common.Utils` osztály tartalmazzon,
  és feladata a paraméterként megadott tömb elemeinek összegzése.
* A `numbers.Classifier` osztályban implementálandó függvények:
	* `int getNumber()` - visszaadja a konstruktornak megadott számot
	* `int numberOfFactors()` - visszaadja a szám osztóinak a számát (az `1`-et, önmagát beleértve)
	* `boolean isFactor(int)` - igazat ad vissza, ha a megadott szám osztó, hamisat különben
	* `int[] getFactors()` - visszaadja az osztók tömbjének egy *másolatát*
	* `boolean isPerfect()`, `boolean isAbundant()`, `boolean isDeficient()` - megadja, hogy a konstruktornak megadott szám tökéletes, bővelkedő vagy hiányos szám-e
	* Szükséges még egy statikus `isPerfect(int)` függvény, ami el tudja dönteni a paraméterként megadott számról, hogy tökéletes-e vagy sem

### Beadás módja ###
**Az alábbi kritériumoknak eleget nem tévő beadandó feladatokat érvénytelennek tekintjük!**

* A beadandókat a gyakorlatvezetőnek küldjétek el e-mailben, egyetlen ZIP
  fájlként mellékelve (*nem tar, nem tgz, nem rar, stb.*). A levél fejléce a következőképp nézzen ki:

		csop<csoportszám>_<EHA kód>_bead1

  Példa:

		csop4_LERIAAT_bead1
		
* A ZIP fájl tartalma a következő szerkezettel rendelkezzen:

		LERIAAT			-	EHA kódnak megfelelú könyvtár
		├───doc			-	Generált Javadoc állományok
		├───numbers		-	Forársállományok, alcsomagok
		│   └───...
		└───README		-	Egy readme fájl.

* A melléklendő `README` fájl tartalma a következő legyen:
  
	  	Első beadandó feladat, 2011-2012/I. félév
  			<Név>
		  	<EHA>
  			<E-mail cím>
  			<Beadás dátuma>
  	
  Ezen kívül bármi érdemleges információt tartalmazhat, ami releváns lehet a
  megoldással kapcsolatban.
  
* A programnak tartalmaznia kell a megfelelően generált Javadoc dokumentációt a `doc` könyvtárban.
  Csak a megoldás során készített osztályokhoz szükséges dokumentációt írni, a feladat kiírásához adott
  tesztállományhoz nem.

* A programnak az alábbi egyetlen paranccsal fordulnia és futnia kell, figyelmeztetések
  és hiba nélkül. *Az olyan beadandó feladatot, amely nem fordul, mérlegelés nélkül elvetjük.*
  
		$> mkdir bin && javac numbers/test/TestClassifier.java -d bin && cd bin && java numbers.test.TestClassifier

* A beadandó feladat *megfelelt minősítést kap*, amennyiben (a fenti feltételeken túl) a mellékelt
  tesztfájl mellett hiba nélkül fut. *A tesztfájlon semmilyen módosítás nem végezhető!*
  A tesztfájl az alábbi linken elérhető: [TestClassifier.java](TestClassifier.java)
