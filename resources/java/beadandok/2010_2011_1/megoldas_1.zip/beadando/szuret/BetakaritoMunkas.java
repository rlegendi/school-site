package szuret;

interface BetakaritoMunkas 
{
	public BetakaritoMunkas osszehasonlit(BetakaritoMunkas b);
	
	public void parbaAllit(BetakaritoMunkas b);
	
	public BetakaritoMunkas getParja();
	
	public int getSebesseg();
	
	public int getOradij();
	
	public String getNev();
	
	// ha ez nincs az interface-ben, akkor pl a Szuret-ben levo BetakaritoMunkas-ra 
	// vonatkoz� equals az az Object-t�l �r�k�lt lesz, �s nem a SzoloSzureteloMunkas-�
	public boolean equals(BetakaritoMunkas b);
}