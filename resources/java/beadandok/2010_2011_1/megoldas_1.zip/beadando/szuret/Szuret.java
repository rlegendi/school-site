package szuret;

abstract class Szuret
{
	protected static int felvasarlasiAr;  // kg/Ft
	protected static int termesMennyisege;  // kg/m2
	protected int maxLetszam=20;
	protected BetakaritoMunkas[] munkasok = new BetakaritoMunkas[maxLetszam];
	protected int munkasokSzama=0;
	protected int terulet; // m2
	
	Szuret(int terulet, int maxLetszam)
	{
		this.terulet=terulet;
		this.maxLetszam=maxLetszam;
		this.munkasok = new BetakaritoMunkas[maxLetszam];
	}
	
	Szuret(int terulet)
	{
		this.terulet=terulet;
		this.munkasok = new BetakaritoMunkas[maxLetszam];
	}
	
	public boolean findMunkas(BetakaritoMunkas m)
	{
		boolean res=false;
		for (BetakaritoMunkas m2 : munkasok)
		{
			if (m.equals(m2)) { res=true; }
		}
		return res;
	}
	
	public void addMunkas(BetakaritoMunkas m)
	{
		if ((munkasokSzama<maxLetszam) && (!findMunkas(m)))
		{
			munkasok[munkasokSzama]=m;
			munkasokSzama++;
		}
	}
	
	public int getMunkasokSzama() { return munkasokSzama; }
	
	public abstract int calcHaszon();
	
	public abstract int calcIdotartam();
	
	public static void setFelvasarlasiAr(int ar) {felvasarlasiAr=ar;}
	
	public static void setTermesMennyisege(int t) {termesMennyisege=t;}
}