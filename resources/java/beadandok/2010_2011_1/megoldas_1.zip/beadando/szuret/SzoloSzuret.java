package szuret;

public class SzoloSzuret extends Szuret
{
	private static int aszuAra;
	private double aszuAranya = 0;
	
	public SzoloSzuret(int maxLetszam, int terulet, double aszuAranya)
	{
		super(terulet, maxLetszam);
		this.aszuAranya=aszuAranya;
	}
	
	public SzoloSzuret(int terulet)
	{
		super(terulet);
	}
	
	public BetakaritoMunkas leglassabb()
	{
		BetakaritoMunkas lassu=munkasok[0];
		for (BetakaritoMunkas m : munkasok)
		{
			if (m!= null) lassu=lassu.osszehasonlit(m);
		}
		return lassu;
	}
	
	public int calcHaszon() 
	{
		double szolo = terulet * termesMennyisege * (1.0-aszuAranya) * felvasarlasiAr;
		double aszu = terulet * termesMennyisege * aszuAranya * aszuAra;
		int oraDijOssz = 0;
		for (BetakaritoMunkas m : munkasok)
		{
			if (m!=null) {oraDijOssz+=m.getOradij();}
		}
		int ber = calcIdotartam()*oraDijOssz;
		return (int)szolo+(int)aszu-ber;
	} 
	
	public int calcIdotartam()
	{
		int osszSeb = 0;
		for (BetakaritoMunkas m : munkasok)
		{
			if (m!=null) {osszSeb+=m.getSebesseg();}
		}
		return terulet * termesMennyisege / osszSeb;
	}

	public static void setAszuAra(int ar) {aszuAra=ar;}
}