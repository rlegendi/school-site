package szuret;

// Tesztelési cékra
public class TesterMunkas implements BetakaritoMunkas
{
	private String nev = "Béla";
	private int oradij = 4000;
	private int sebesseg = 300; // kg/óra
	private BetakaritoMunkas parja = null;
		
	public BetakaritoMunkas osszehasonlit(BetakaritoMunkas b)
	{
		return this;	
	}
	
	public void parbaAllit(BetakaritoMunkas b)
	{
		if ((this.parja==null) || (!this.parja.equals(b))) 
		{ 
			this.parja=b;
			this.sebesseg*=1.1;
			b.parbaAllit(this);
		}
	}
	
	public BetakaritoMunkas getParja() { return this.parja; }
	
	public int getSebesseg() {return sebesseg; }
	
	public int getOradij() {return oradij; }
	
	public String getNev() {return nev; }
	
	public boolean equals(BetakaritoMunkas m)
	{
		if (m == null)
		{
			return false;
		}
		else
		{
			return (this.nev==m.getNev());
		}
	}
	
	public String toString()
	{
		return "TesterMunkas";
	}
}