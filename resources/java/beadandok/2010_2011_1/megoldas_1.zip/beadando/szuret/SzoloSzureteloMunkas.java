package szuret;

public class SzoloSzureteloMunkas implements BetakaritoMunkas
{
	private String nev;
	private int oradij;
	private int sebesseg; // kg/�ra
	private BetakaritoMunkas parja = null;
	
	public SzoloSzureteloMunkas(String nev, int oradij, int sebesseg, double aszuszedesOkoztaLassulas)
	{
		this.nev=nev;
		this.oradij=oradij;
		this.sebesseg=(int)(aszuszedesOkoztaLassulas*(double)sebesseg);
		//nem sz�ks�ges a lassul�st let�rolni
	}
	
	public BetakaritoMunkas osszehasonlit(BetakaritoMunkas b)
	{
		if (this.sebesseg>b.getSebesseg())
		{
			return b;
		}
		else
		{
			return this;
		}
	}
	
	//v�gtelen rekurzi� vesz�lye
	public void parbaAllit(BetakaritoMunkas b)
	{
		if ((this.parja==null) || (!this.parja.equals(b))) 
		{ 
			this.parja=b;
			this.sebesseg*=110/100;
			b.parbaAllit(this);
		}
	}
	
	public BetakaritoMunkas getParja() { return this.parja; }
	
	public int getSebesseg() {return sebesseg; }
	
	public int getOradij() {return oradij; }
	
	public String getNev() {return nev; }
	
	public boolean equals(BetakaritoMunkas m)
	{
		if (m == null)
		{
			return false;
		}
		else
		{
			return (this.nev==m.getNev());
		}
	}
	
	public String toString()
	{
		return "Munkas neve: " + this.nev + ", sebessege: " + this.sebesseg + ", oradijja: " + this.oradij;
	}
}