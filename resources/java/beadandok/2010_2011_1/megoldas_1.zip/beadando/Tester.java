import szuret.*;

class Tester
{
    public static void main(String[] args)
    {
        SzoloSzureteloMunkas munkas1 = new SzoloSzureteloMunkas("Béla",5000,100,0.7);
        SzoloSzureteloMunkas munkas2 = new SzoloSzureteloMunkas("János",6000,120,0.6);
        System.out.println(munkas1.osszehasonlit(munkas2));  // helyes: Béla

        munkas1.parbaAllit(munkas2);
        System.out.println(munkas1.getNev() + " parja: " + munkas1.getParja());  // Béla páa János
        System.out.println(munkas2.getNev() + " parja: " + munkas2.getParja());  // János párja Béla

        SzoloSzureteloMunkas munkas3 = new SzoloSzureteloMunkas("Béla",1000,10,0.2);
        SzoloSzureteloMunkas munkas4 = new SzoloSzureteloMunkas("Geza",10000,90,0.4);
        System.out.println("Egyenlo: " +munkas3.equals(munkas1));  // helyes: true
        System.out.println("Egyenlo null-al: " + munkas1.equals(null));  // helyes: false

        SzoloSzuret szuret1 = new SzoloSzuret(2,5000,0.2);
        SzoloSzuret szuret2 = new SzoloSzuret(500);
        szuret1.addMunkas(munkas1);
        System.out.println("Add, find: " + szuret1.findMunkas(munkas3));  // helyes: true
        szuret1.addMunkas(munkas3);
        szuret1.addMunkas(munkas2);
        System.out.println("Add, find: " + szuret1.findMunkas(munkas2));  // helyes: true
        szuret1.addMunkas(munkas4);
        System.out.println("Add, find: " + szuret1.findMunkas(munkas4));  // helyes: false

        System.out.println("Haszon: " + szuret1.calcHaszon());  // helyes: 0
        System.out.println("Idotartam: " + szuret1.calcIdotartam());  // helyes: 0

        szuret2.addMunkas(munkas2);
        szuret2.addMunkas(munkas4);  
        System.out.println("Munkasok szama: " + szuret2.getMunkasokSzama());  // helyes: 2

        SzoloSzuret.setTermesMennyisege(4);
        SzoloSzuret.setFelvasarlasiAr(65);
        SzoloSzuret.setAszuAra(4000);

        System.out.println("Haszon: " + szuret1.calcHaszon());  // helyes: 15500000
        System.out.println("Idotartam: " + szuret1.calcIdotartam());  // helyes: 140

        System.out.println("Haszon: " + szuret2.calcHaszon());  // helyes: -158000
        System.out.println("Idotartam: " + szuret2.calcIdotartam());  // helyes: 18

        System.out.println("Leglassabb: " + szuret2.leglassabb());  // helyes: Géza
	
        // Ez biztos a saját tesztelésünk része lesz
        System.out.println("============================================");
        TesterMunkas t = new TesterMunkas();
        System.out.println(t.osszehasonlit(munkas1));  // helyes: TesterMunkas
        munkas3.parbaAllit(t);  
        System.out.println(munkas3.getNev() + " parja: " + munkas3.getParja());  // Béla párja TesterMunkas
        System.out.println("Egyenlo Testerrel:" + munkas3.equals(t));  // helyes: true

        szuret2.addMunkas(t);

        System.out.println("Haszon: " + szuret2.calcHaszon());  // helyes: 50000
        System.out.println("Idotartam: " + szuret2.calcIdotartam());  // helyes: 4

        // innen 12 error-t kell dobnia
        /*
        munkas1.nev="valami";
        munkas1.oradij=0;
        munkas1.sebesseg=0;
        munkas1.parja=null;

        szuret1.felvasarlasiAr=0;
        szuret1.termesMennyisege=0;
        szuret1.maxLetszam=20;
        szuret1.munkasok = null;
        szuret1.munkasokSzama=0;
        szuret1.terulet=0;
        szuret1.aszuAra=0;
        szuret1.aszuAranya = 0;
        */
	}
}