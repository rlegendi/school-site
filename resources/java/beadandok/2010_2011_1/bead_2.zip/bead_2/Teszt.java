import sutes.*;
import java.util.*;
import java.io.*;

public class Teszt {
    
    public static void main(String[] args) {

        System.out.println("--------------------------------------------------");
        Hozzavalo tojas1 = new Tojas(1);
        Hozzavalo tej1 = new Tej(200);
        Hozzavalo liszt1 = new Liszt(500);
        
        System.out.println(tojas1 + " tomege: " + tojas1.getTomeg() + 
                           " g, terfogata: " + tojas1.getTerfogat() + " cm3");
        // 1.0 db tojas tomege: 60.0 g, terfogata: 57.636887608069166 cm3

        System.out.println(tej1 + " tomege: " + tej1.getTomeg() + 
                           " g, terfogata: " + tej1.getTerfogat() + " cm3");
        // 200.0 ml tej tomege: 206.0 g, terfogata: 200.0 cm3
        
        System.out.println(liszt1 + " tomege: " + liszt1.getTomeg() + 
                           " g, terfogata: " + liszt1.getTerfogat() + " cm3");
        // 500.0 g liszt tomege: 500.0 g, terfogata: 806.4516129032259 cm3

        System.out.println("--------------------------------------------------");
        List<Hozzavalo> hozzavalok = new LinkedList<Hozzavalo>();
        hozzavalok.add(tojas1);
        Tojas tojas2 = new Tojas(2);
        hozzavalok.add(tojas2);
        hozzavalok.add(liszt1);
        hozzavalok.add(tej1);
        hozzavalok.add(new Liszt(100));
        hozzavalok.add(new Tojas(5));
        hozzavalok.add(new Tej(610));
        System.out.println("A hozzavalok osszegezve: ");
        System.out.println(" - " + Tojas.osszegez(hozzavalok)); // 8.0 db tojas
        System.out.println(" - " + Liszt.osszegez(hozzavalok)); // 600.0 g liszt
        System.out.println(" - " + Tej.osszegez(hozzavalok)); // 810.0 ml tej
        PalacsintaTeszta teszta = new PalacsintaTeszta(hozzavalok);

        System.out.println("--------------------------------------------------");
        System.out.println("Az alapteszta hozzavaloi: " + 
                           PalacsintaTeszta.getAlapteszta().getHozzavalok());
        // [300.0 g liszt, 4.0 db tojas, 400.0 ml tej] -> a megadott tesztfajllal
        // [250.0 g liszt, 3.0 db tojas, 300.0 ml tej] -> alapteszta.txt nelkul

        System.out.println("--------------------------------------------------");
        System.out.println("A liszt aranya: " + teszta.getLisztArany());
        // 0.3134
        System.out.println("A tej aranya: " + teszta.getTejArany()); 
        // 0.4358
        System.out.println("A tojas aranya: " + teszta.getTojasArany());
        // 0.2507

        System.out.println("A teszta surusege: " + teszta.getTesztaSuruseg()); 
        // 0.8556

        System.out.println("--------------------------------------------------");
        System.out.println("A teszta hozzavaloi sutes elott: " + 
                           teszta.getHozzavalok()); 
        // [1.0 db tojas, 2.0 db tojas, 500.0 g liszt, 200.0 ml tej, 
        //  100.0 g liszt, 5.0 db tojas, 610.0 ml tej]

        Serpenyo serp = new Serpenyo(15);
        double vastagsag = 0.2;
        System.out.println("Ebbol a tesztabol " + teszta.kisut(serp,vastagsag) 
                           + " db 0.2 cm vastag palacsinta sutheto ki."); // 15

        System.out.println("A teszta hozzavaloi sutes utan: " + 
                           teszta.getHozzavalok()); 
        // []
        
        System.out.println("--------------------------------------------------");
        teszta.addHozzavalo(new Liszt(200));
        teszta.addHozzavalo(new Tojas(10));
        teszta.addHozzavalo(new Tej(200));
        System.out.println("A teszta hozzavaloi sutes elott: " + 
                           teszta.getHozzavalok()); 
        // [200.0 g liszt, 10.0 db tojas, 200.0 ml tej]

        System.out.println("Ebbol a tesztabol " + teszta.kisut(serp,vastagsag) 
                           + " db 0.2 cm vastag palacsinta sutheto ki."); 
        // Exception in thread "main" java.lang.UnsupportedOperationException:
        // Nem jo a teszta, nem lehet sutni belole.
    }
}