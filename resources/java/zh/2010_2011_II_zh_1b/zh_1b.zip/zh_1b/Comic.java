package media.data;

import java.util.Collection;
import java.util.Collections;

// TODO Newspaper leszarmazott legyen
public class Comic {
	protected String title;
	protected int copies;
	protected String author;
	protected String series;
	
	public String getTitle() {
		return title;
	}
	
	public int getCopies() {
		return copies;
	}
	
	public String getAuthor() {
		return author;
	}
	
	public String getSeries() {
		return series;
	}
	
	public static Collection<Comic> getDefaultCollection() {
		// TODO Minimum egy elemet visszaadni!
		return Collections.emptyList();
	}
}
