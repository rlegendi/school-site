package zh3;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class CinemaClient implements ActionListener{
	protected JFrame frame;
	private final JTextArea textArea = new JTextArea();
	protected JTextField idField = new JTextField();
	protected JButton buyTicketButton = new JButton( "Buy ticket" );
	
	protected JMenuItem getShowTimesMenuItem = new JMenuItem( "Get show times" );
	
	public CinemaClient(){
		frame = new JFrame();
		frame.setTitle("CinemaClient GUI");
		frame.setJMenuBar( createMenu() );
		
		buyTicketButton.addActionListener( this );
		
		frame.getContentPane().setLayout( new FlowLayout() );
		
		JScrollPane scrollPane = new JScrollPane( textArea );
		textArea.setBackground(Color.white);
		scrollPane.setPreferredSize( new Dimension(280,300) );
		frame.getContentPane().add( scrollPane );
		frame.getContentPane().add( new JLabel("Show time id: ") );
		idField.setColumns(5);
		frame.getContentPane().add( idField );
		frame.getContentPane().add( buyTicketButton );
		frame.setPreferredSize(new Dimension(300,400));
	}
	
	public static void createAndShowGUI(){
		CinemaClient client = new CinemaClient();
		JFrame frame = client.getFrame();
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				createAndShowGUI();
			}
		});
	}

	public JFrame getFrame(){
		return frame;
	}
	
	private JMenuBar createMenu() {
		JMenuBar menuBar = new JMenuBar();
		JMenu file = new JMenu("File");
		file.setMnemonic('f');
		
		getShowTimesMenuItem.setActionCommand("getShowTime");
		getShowTimesMenuItem.addActionListener( this );
		
		file.add( getShowTimesMenuItem );

		menuBar.add(file);
		return menuBar;
	}
	
	protected void getDataOnSocket(String server, int port ){
		String errorMsg = null;

		Socket socket = null;
		PrintWriter out = null;
		BufferedReader in = null;
		try {
			socket = new Socket(server, port);
			out = new PrintWriter(socket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(socket
					.getInputStream()));
		} catch (UnknownHostException e) {
			textArea.setText( "A szerver nem talalhato: " + server );
		} catch (IOException e) {
			textArea.setText( "nem sikerult megnyitni az I/O-t: " + server );
		}
		
		textArea.append( "ID\tFilm\tIdopont\n" );
		
		try{
			out.println( "**get data**" );
			String inputLine;
			String showTime = "";
			int cnt = 0;
		    while ((inputLine = in.readLine()) != null) {
		    	showTime += inputLine;
		    	if( ++cnt == 3 ){
		    		cnt = 0;
		    		textArea.append( showTime + "\n" );
		    		showTime = "";
		    	}
		    }
			
			if( "null".equals( errorMsg ) ) errorMsg = null;

			in.close();
			socket.close();
		}catch( IOException e ){
			textArea.setText( e.getLocalizedMessage() );
		}finally{
			out.close();
		}
	}

	protected String sendDataOnSocket(String server, int port, String msg){
		String errorMsg = null;

		Socket socket = null;
		PrintWriter out = null;
		BufferedReader in = null;
		try {
			socket = new Socket(server, port);
			out = new PrintWriter(socket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(socket
					.getInputStream()));
		} catch (UnknownHostException e) {
			return "A szerver nem talalhato: " + server;
		} catch (IOException e) {
			return "nem sikerult megnyitni az I/O-t: " + server;
		}
		
		try{
			out.println( msg );
			errorMsg = in.readLine();
			
			if( "null".equals( errorMsg ) ) errorMsg = null;

			in.close();
			socket.close();
		}catch( IOException e ){
			return e.getLocalizedMessage();
		}finally{
			out.close();
		}

		return errorMsg;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if( e.getActionCommand().equals( "getShowTime" ) ){
			getDataOnSocket( "localhost", 11 );
		}
	}
}
