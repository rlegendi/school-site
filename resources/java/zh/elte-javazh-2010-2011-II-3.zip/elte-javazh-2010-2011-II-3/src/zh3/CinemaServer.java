package zh3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

public class CinemaServer {
	protected static File showTimeFile = new File( "data.txt" );
	protected static DBAdapter adapter = new DBAdapter();
	
	protected static List<ShowTime> showTimes = new ArrayList<ShowTime>();
	
	public static void main( String[] args ){
		readShowTimes();
		
		connectToDB();
		
		runInSocketMode();
		
		disconnectFromDB();
	}
	
	protected static void runInSocketMode(){
		ServerSocket serverSocket = null;
		
		try {
			serverSocket = new ServerSocket(11);
		} catch (IOException e) {
			System.out.println("Nem sikerult elinditani a szervert a 11-es porton");
			return;
		}
		
		System.out.println("A szerver fut.");
		
		Socket clientSocket = null;
		BufferedReader in = null;
		PrintWriter out = null;
		
		while( true ){
			clientSocket = null;
			try {
				clientSocket = serverSocket.accept();
			} catch (IOException e) {
				System.out.println("Csatlakozas sikertelen.");
				continue;
			}
			
			try{
				out = new PrintWriter(clientSocket.getOutputStream(), true);
				in = new BufferedReader( new InputStreamReader(
														clientSocket.getInputStream()));
				
				String firstLine = in.readLine();
				if( "**get data**".equals( firstLine ) ){
					/*ArrayList<Object[]> result = 
			            adapter.select( new String[]{ "data" }, 
			                            new String[]{ "dataTable" }, null, null );
					
					adapter.commit();
					String res = "";
			        
			        for( int i = 0; i < result.size(); ++i ){
			            for( int j = 0; j < result.get( i ).length; ++j ){
			                if( j > 0 ) res += ";";
			                res += String.valueOf( result.get( i )[j] );
			            }
			            res += "\n";
			        }
			        
			        out.println( res );*/
					for( int i = 0; i < showTimes.size(); ++i ){
						out.println( showTimes.get( i ).id + "\t" );
						out.println( showTimes.get( i ).movie + "\t" );
						out.println( showTimes.get( i ).schedule + "\t" );
					}
				}else{
					String errorMsg = saveData( firstLine );
					//errorMsg = saveDataToDB( data );
					out.println( errorMsg );
				}
				
				in.close();
				clientSocket.close();
			}catch( IOException e ){
				e.printStackTrace();
			}finally{
				out.close();
			}
		}
		//serverSocket.close();
	}
	
	protected static String saveData( String msg ){
		PrintWriter writer = null;
		
		try{
			writer = new PrintWriter( new FileWriter( "log.txt", true ) );
			writer.println( msg );
		}catch( IOException e ){
			return "Nem sikerult menteni az adatot:\n" + e.getLocalizedMessage();
		}finally{
			if( writer != null ) writer.close();
		}
		
		return null;
	}
	
	protected static void readShowTimes(){
		BufferedReader reader = null;
		try{
			reader = new BufferedReader( new FileReader( showTimeFile ) );
			
			while( reader.ready() ){
				String line = reader.readLine();
				StringTokenizer tokenizer = new StringTokenizer( line, ";" );
				int id = Integer.valueOf( tokenizer.nextToken() );
				String movie = tokenizer.nextToken();
				String schedule = tokenizer.nextToken();
				int maxTickets = Integer.valueOf( tokenizer.nextToken() );
				ShowTime st = new ShowTime( id, movie, schedule, maxTickets );
				boolean success = addShowTime( st );
				if( !success )
					System.out.println( "Duplicate show time: " + st.toString() );
			}
		}catch( NoSuchElementException e ){
			e.printStackTrace();
		}catch( FileNotFoundException e ){
			e.printStackTrace();
		}catch( IOException e ){
			e.printStackTrace();
		}finally{
			if( reader != null ){
				try{ reader.close(); }catch( IOException e ){ /*no plan*/ }
			}
		}
	}
	
	protected static boolean addShowTime( ShowTime st ){
		for( int i = 0; i < showTimes.size(); ++i ){
			if( st.equals( showTimes.get( i ) ) ) return false;
		}
		
		showTimes.add( st );
		
		return true;
	}
	
	protected static String saveDataToDB( String msg ){
		
        adapter.executeQuery( "insert into dataTable values( '" + msg+ "' )" );
        
        adapter.commit();
        printValuesFromDB();
        
		return null;
	}
	
	protected static void printValuesFromDB(){
		ArrayList<Object[]> result = 
            adapter.select( new String[]{ "data" }, 
                            new String[]{ "dataTable" }, null, null );
		
		adapter.commit();
        
        System.out.println( "Eredmeny:" );
        
        for( int i = 0; i < result.size(); ++i ){
            for( int j = 0; j < result.get( i ).length; ++j ){
                if( j > 0 ) System.out.print( ";" );
                System.out.print( String.valueOf( result.get( i )[j] ) );
            }
            System.out.println();
        }
	}
	
	protected static void connectToDB(){
		adapter.connect( "probaDB", true );
        adapter.executeQuery( "drop table dataTable" );
        adapter.executeQuery( "create table dataTable( data varchar(250) )" );
	}
	
	protected static void disconnectFromDB(){
        adapter.disconnect();
	}

}
