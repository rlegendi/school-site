package zh3;

public class ShowTime {
	protected int id;
	protected String movie;
	protected String schedule;
	protected int maxTickets;
	protected int availableTickets;
	
	public ShowTime( int id, String movie, String schedule, int maxTickets ){
		this.id = id;
		this.movie = movie;
		this.schedule = schedule;
		this.maxTickets = maxTickets;
		availableTickets = maxTickets;
	}
	
	public boolean sellTicket(){
		if( availableTickets > 0 ){
			--availableTickets;
			return true;
		}else{
			return false;
		}
	}
	
	@Override
	public boolean equals( Object o ){
		if( !(o instanceof ShowTime) ) return false;
		
		return id == ((ShowTime)o).id;
	}
	
	@Override
	public String toString(){
		return id + ";" + movie + ";" + schedule;
	}
}
