package javazh.test;

import javazh.train.*;
import javazh.train.Carriage.CarriageType;
import javazh.train.exception.*;
import java.lang.reflect.*;

public class TrainTester {

	public static void main(String[] args) {
		int mark = 1;
		if(inheritanceTester()) {
			mark++;
		}
		if(trainTester()) {
			mark++;
		}
		if(readTester()) {
			mark++;
		}
		if(exceptionAndEqualsTester()) {
			mark++;
		}

		System.out.println("Your mark is " + mark);
	}

	private static boolean inheritanceTester() {
		boolean success = false;

		try {
			//m�dos�t�k tesztje
			int mod = Trainset.class.getModifiers();
			if(!Modifier.isAbstract(mod)) {
				System.err.println("Error in inheritanceTester: abstract");
				return false;
			}

			try {
				mod = Locomotive.class.getDeclaredField("isElectric").getModifiers();
				if(!Modifier.isPrivate(mod)) {
					System.err.println("Error inheritanceTester: visibility");
					return false;
				}
				if(!Modifier.isFinal(mod)) {
					System.err.println("Error in inheritanceTester: finalized1");
					return false;
				}
			}
			catch(NoSuchFieldException ex) {
				System.err.println("Error in inheritanceTester: missing isElectric field");
				return false;
			}

			Trainset l = new Locomotive("Locomotive2", true);
			Trainset c = new Carriage("Carriage1", Carriage.CarriageType.SECOND, 102);

			success = true;
		}
		catch(Exception ex) {
			System.err.println("Unexpected error: " + ex.getMessage());
			ex.printStackTrace();
		}

		return success;
	}

	private static boolean trainTester() {
		boolean success = false;

		try {
			Train t = new Train("HajduExpress", new Locomotive("Locomotive", false));
			
			t.add("Carriage1", Carriage.CarriageType.FIRST, 80);
			t.add("Carriage2", Carriage.CarriageType.FIRST, 80);
			//vonathossza lek�rdez�se
			if(3 != t.getLength()) {
				System.err.println("Error in trainTester: getLength1");
				return false;
			}

			t.add("Carriage3", Carriage.CarriageType.DINER, 15);
			t.add("Carriage4", Carriage.CarriageType.SECOND, 102);

			//els� oszt�ly� kocsi csak a vonat elej�n lehet
			try {
				t.add("Carriage5", Carriage.CarriageType.FIRST, 80);
			}
			catch(Exception ex) {}
			if(5 != t.getLength()) {
				System.err.println("Error in trainTester: getLength2");
				return false;
			}

			t.add("Carriage5", Carriage.CarriageType.SECOND, 102);

			//2. kocsi lek�rdez�se
			if(!((Carriage)t.getTrain().get(2)).getName().equals("Carriage2")) {
				System.err.println("Error in trainTester: getName");
				return false;
			}

			success = true;
		}
		catch(Exception ex) {
			System.err.println("Unexpected error: " + ex.getMessage());
			ex.printStackTrace();
		}

		return success;
	}

	private static boolean readTester() {
		boolean success = false;

		try {
			Train t = Train.read("train.txt");

			//vonathossza lek�rdez�se
			if(4 != t.getLength()) {
				System.err.println("Error in readTester: getLength");
				return false;
			}

			//mozdony t�pus�nak lek�rdez�se
			if(!((Locomotive)t.getTrain().get(0)).isElectric()) {
				System.err.println("Error in readTester: isElectric");
				return false;
			}

			//2. kocsi f�r�helyeinek a sz�ma
			if(((Carriage)t.getTrain().get(2)).getPlaceNum() != 85) {
				System.err.println("Error in readTester: getPlaceNum");
				return false;
			}

			//3. kocsi t�pus�nak lek�rdez�se
			if(!((Carriage)t.getTrain().get(3)).getType().equals(Carriage.CarriageType.DINER)) {
				System.err.println("Error in readTester: getPlaceNum");
				return false;
			}

			success = true;
		}
		catch(Exception ex) {
			System.err.println("Unexpected error: " + ex.getMessage());
			ex.printStackTrace();
		}

		return success;
	}

	private static boolean exceptionAndEqualsTester() {
		boolean success = false, exception = false;

		try {
			Train t = new Train("HajduExpress", new Locomotive("Locomotive", false));
			
			t.add("Carriage1", Carriage.CarriageType.FIRST, 80);
			t.add("Carriage2", Carriage.CarriageType.FIRST, 80);
			t.add("Carriage3", Carriage.CarriageType.DINER, 15);
			t.add("Carriage4", Carriage.CarriageType.SECOND, 102);

			//els� oszt�ly� kocsi csak a vonat elej�n lehet
			try {
				t.add("Carriage5", Carriage.CarriageType.FIRST, 80);
			}
			catch(AddCarriageException ex) {
					exception = true;
			}

			t.add("Carriage5", Carriage.CarriageType.SECOND, 102);

			if(6 != t.getLength()) {
				System.err.println("Error in exceptionAndEqualsTester: getLength");
				return false;
			}

			//equals tesztje
			Carriage c = (Carriage)t.getTrain().get(1);
			Locomotive l = (Locomotive)t.getTrain().get(0);
			Carriage c1 = new Carriage("Carriage1", Carriage.CarriageType.FIRST, 80);
			Carriage c2 = new Carriage("Carriage2", Carriage.CarriageType.FIRST, 80);
			Carriage c3 = new Carriage("Carriage1", Carriage.CarriageType.FIRST, 40);
			Carriage c4 = new Carriage("Carriage1", Carriage.CarriageType.SECOND, 80);

			if(c.equals(l)) {
				System.err.println("Error in exceptionAndEqualsTester: equals1");
				return false;
			}
			if(!c.equals(c1)) {
				System.err.println("Error in exceptionAndEqualsTester: equals2");
				return false;
			}
			if(c.equals(c2)) {
				System.err.println("Error in exceptionAndEqualsTester: equals3");
				return false;
			}
			if(c.equals(c3)) {
				System.err.println("Error in exceptionAndEqualsTester: equals4");
				return false;
			}
			if(c.equals(c4)) {
				System.err.println("Error in exceptionAndEqualsTester: equals5");
				return false;
			}

			success = true;
		}
		catch(Exception ex) {
			System.err.println("Unexpected error: " + ex.getMessage());
			ex.printStackTrace();
		}

		return success && exception;
	}
}
