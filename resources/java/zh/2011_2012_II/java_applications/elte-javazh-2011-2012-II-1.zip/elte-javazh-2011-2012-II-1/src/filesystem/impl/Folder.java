package filesystem.impl;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import filesystem.IEntry;
import filesystem.IFolder;

public class Folder
		extends Entry
		implements IFolder {
	
	private final Set<IEntry> entries = new HashSet<IEntry>();
	
	public Folder(final IFolder parent, final String name) {
		super( parent, name );
	}
	
	public static IFolder createRootFolder(final String name) {
		final Folder root = new Folder( null, name );
		Entry.root = root;
		return root;
	}
	
	@Override
	public void add(final IEntry entry) {
		entries.add( entry );
	}
	
	@Override
	public void remove(final IEntry entry) {
		entries.remove( entry );
	}
	
	@Override
	public boolean containsEntry(final IEntry entry) {
		return entries.contains( entry );
	}
	
	@Override
	public boolean isEmptyFolder() {
		return entries.isEmpty();
	}
	
	@Override
	public boolean isRootFolder() {
		return equals( root );
	}
	
	@Override
	public Collection<IEntry> entries() {
		return Collections.unmodifiableCollection( entries );
	}
}
