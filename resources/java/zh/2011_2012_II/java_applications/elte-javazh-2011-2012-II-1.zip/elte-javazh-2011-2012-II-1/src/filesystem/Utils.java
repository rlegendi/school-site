package filesystem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Utils {
	
	// ======================================================================================================================
	// +1
	
	public static int totalSizeOf(final IFolder root) {
		int ret = 0;
		
		for (final IEntry act : root.entries()) {
			ret += act.size();
			
			if ( act instanceof IFolder ) {
				final IFolder subfolder = (IFolder) act;
				ret += totalSizeOf( subfolder );
			}
		}
		
		return ret;
	}
	
	// ======================================================================================================================
	// +1
	
	public static int minEntrySize(final IFolder root) {
		final List<IEntry> sortedEntries = sortedEntries( root );
		return sortedEntries.get( 0 ).size();
	}
	
	public static int maxEntrySize(final IFolder root) {
		final List<IEntry> sortedEntries = sortedEntries( root );
		return sortedEntries.get( sortedEntries.size() - 1 ).size();
	}
	
	public static List<IEntry> sortedEntries(final IFolder root) {
		final ArrayList<IEntry> ret = new ArrayList<IEntry>( root.entries() );
		Collections.sort( ret );
		return ret;
	}
	
}
