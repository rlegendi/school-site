package filesystem;

import java.util.Collection;

public interface IFolder
		extends IEntry {
	
	// 2
	
	public abstract boolean isEmptyFolder();
	
	public abstract boolean isRootFolder();
	
	public Collection<IEntry> entries();
	
	public abstract void add(IEntry entry);
	
	public abstract void remove(IEntry entry);
	
	public abstract boolean containsEntry(IEntry entry);
	
}
