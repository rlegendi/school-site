package filesystem.test;

import java.util.Arrays;
import java.util.List;

import filesystem.IEntry;
import filesystem.IFile;
import filesystem.IFolder;
import filesystem.Utils;
import filesystem.impl.File;
import filesystem.impl.Folder;

public class FileSystemTest {
	
	private static final boolean dumpExceptions = false;
	
	// ======================================================================================================================
	// Mark 2
	
	public void testSimpleFileContents() {
		final IFolder root = Folder.createRootFolder( "/" );
		
		final IFile f = new File( root, "f.txt", "Some content" );
		assertEquals( "File content stored correctly.", f.getContent(), "Some content" );
		assertEquals( "File size evaluated correctly.", f.size(), 12 );
	}
	
	public void testFolderSize() {
		final IFolder root = Folder.createRootFolder( "/" );
		assertEquals( "Folder size must be 0.", 0, root.size() );
	}
	
	public void testFolderEmptyness() {
		final IFolder root = Folder.createRootFolder( "/" );
		assertThat( "Initiated root folder must be empty.", root.isEmptyFolder() );
	}
	
	public void testRootFolderIsRootFolder() {
		final IFolder root = Folder.createRootFolder( "/" );
		assertThat( "Initiated root folder must be the root folder.", root.isRootFolder() );
	}
	
	public void testNotEmptyFolderEmptyness() {
		final IFolder root = Folder.createRootFolder( "/" );
		
		new Folder( root, "subfolder" ); // Implicit addition
		assertThat( "Root folder with a folder must not be empty.", ! root.isEmptyFolder() );
	}
	
	public void testSubfolderIsNotRoot() {
		final IFolder root = Folder.createRootFolder( "/" );
		
		final IFolder subfolder = new Folder( root, "subfolder" );
		assertThat( "Root folder with a folder must not be empty.", ! subfolder.isRootFolder() );
	}
	
	public void testFolderContains() {
		final IFolder root = Folder.createRootFolder( "/" );
		
		final IFolder subfolder = new Folder( root, "subfolder" );
		final IFile file = new File( subfolder, "f.txt", "F" );
		
		assertThat( "Root folder must contain added folders.", root.containsEntry( subfolder ) );
		assertThat( "Subfolder must contain added file.", subfolder.containsEntry( file ) );
	}
	
	public void testRemove() {
		final IFolder root = Folder.createRootFolder( "/" );
		final IFile file = new File( root, "f.txt", "F" );
		
		root.remove( file );
		assertThat( "Folder must not contain removed file.", ! root.containsEntry( file ) );
	}
	
	// ======================================================================================================================
	// Mark +1
	
	public void testFileDeletion() {
		final IFolder root = Folder.createRootFolder( "/" );
		final IFile file = new File( root, "f.txt", "Some content" );
		
		file.delete();
		assertThat( "Deletion should remove file from parent's entries.", ! root.containsEntry( file ) );
	}
	
	public void testFolderDeletion() {
		final IFolder root = Folder.createRootFolder( "/" );
		final IFolder subfolder = new Folder( root, "subfolder" );
		
		subfolder.delete();
		assertThat( "Deletion should remove subfolder from parent's entries.", ! root.containsEntry( subfolder ) );
	}
	
	public void testFileMove() {
		final IFolder root = Folder.createRootFolder( "/" );
		final IFolder subfolder = new Folder( root, "subfolder" );
		final IFile file = new File( root, "f.txt", "F" );
		
		file.moveTo( subfolder );
		assertThat( "Moving must remove entry from parent's entries.", ! root.containsEntry( file ) );
		assertThat( "Moving must add entry to new parent's entries.", subfolder.containsEntry( file ) );
	}
	
	public void testFolderRename() {
		final IFolder root = Folder.createRootFolder( "/" );
		final IFolder subfolder = new Folder( root, "subfolder" );
		
		subfolder.rename( "zubfolder" );
		assertEquals( "Renaming must change name of the folder.", "zubfolder", subfolder.getName() );
	}
	
	// ====================================================================================================================
	// Mark +1
	
	public void testAbsolutePath() {
		final IFolder root = Folder.createRootFolder( "/" );
		assertEquals( "Root folder path should be its name only.", "/", root.getAbsolutePath() );
		
		final IFolder folder = new Folder( root, "folder" );
		assertEquals( "Absolute path of a folder must be as specified.", "/folder", folder.getAbsolutePath() );
		
		final IFile file = new File( folder, "f.txt", "Some content" );
		assertEquals( "Absolute path of a file must be as specified.", "/folder/f.txt", file.getAbsolutePath() );
	}
	
	public void testTotalSize() {
		final IFolder root = Folder.createRootFolder( "/" );
		final IFile f = new File( root, "f.txt", "f" );
		
		final IFolder subfolder = new Folder( root, "folder" );
		final IFile g = new File( subfolder, "g.txt", "GG" );
		final IFile h = new File( subfolder, "h.txt", "hhh" );
		
		final int size = Utils.totalSizeOf( root );
		assertEquals( "Totla size of a folder must be recursive.", f.size() + g.size() + h.size(), size );
	}
	
	// ======================================================================================================================
	// Mark +1
	
	public void testMinEntrySize() {
		final IFolder root = Folder.createRootFolder( "/" );
		final IFile f = new File( root, "f.txt", "f" );
		
		// Implicit additions
		new File( root, "g.txt", "GG" );
		new File( root, "h.txt", "hhh" );
		
		final int minSize = Utils.minEntrySize( root );
		assertEquals( "Min entry should be the entry with the lowest size.", f.size(), minSize );
	}
	
	public void testMaxEntrySize() {
		final IFolder root = Folder.createRootFolder( "/" );
		
		// Implicit additions
		new File( root, "f.txt", "f" );
		new File( root, "g.txt", "GG" );
		
		final IFile h = new File( root, "h.txt", "hhh" );
		
		final int maxSize = Utils.maxEntrySize( root );
		assertEquals( "Max entry should be the entry with the highest size.", h.size(), maxSize );
	}
	
	public void testSortedEntries() {
		final IFolder root = Folder.createRootFolder( "/" );
		
		final IFile f = new File( root, "f.txt", "f" );
		final IFile g = new File( root, "g.txt", "GG" );
		final IFile h = new File( root, "h.txt", "hhh" );
		
		final List<IEntry> sortedEntries = Utils.sortedEntries( root );
		assertEquals( "Min entry should be the entry with the lowest size.", Arrays.asList( f, g, h ), sortedEntries );
	}
	
	// ======================================================================================================================
	
	private void assertEquals(final String msg, final Object expected, final Object actual) {
		if ( ! expected.equals( actual ) ) {
			throw new AssertionError( "[FAILED] " + msg + " (expected: " + expected + ", actual: " + actual + ")" );
		}
		
		System.out.println( "[OK] " + msg );
	}
	
	private void assertThat(final String message, final boolean assertion) {
		if ( ! assertion ) {
			throw new AssertionError( "[FAILED] " + message );
		}
		
		System.out.println( "[OK] " + message );
	}
	
	public static void main(final String[] args) {
		final FileSystemTest test = new FileSystemTest();
		
		int mark = 1;
		
		if ( test.mark2() ) {
			mark++;
			
			if ( test.checkAdditionalFileOperations() ) {
				mark++;
			}
			
			if ( test.checkRecursiveQueries() ) {
				mark++;
			}
			
			if ( test.checkSorting() ) {
				mark++;
			}
		}
		
		System.out.println( "=============" );
		System.out.println( "   Mark: " + mark );
		System.out.println( "=============" );
	}
	
	private boolean mark2() {
		try {
			testSimpleFileContents();
			testFolderSize();
			testFolderEmptyness();
			testRootFolderIsRootFolder();
			testNotEmptyFolderEmptyness();
			testSubfolderIsNotRoot();
			testFolderContains();
			testRemove();
			
			System.out.println( "=== Mark 2: Done ===" );
			System.out.println();
			return true;
		} catch (final Throwable e) {
			System.out.println( e.getMessage() );
			
			if ( dumpExceptions ) {
				e.printStackTrace();
			}
			
			return false;
		}
	}
	
	private boolean checkAdditionalFileOperations() {
		try {
			testFileDeletion();
			testFolderDeletion();
			testFileMove();
			testFolderRename();
			
			System.out.println( "=== Mark +1: Additional file operations done ===" );
			System.out.println();
			return true;
		} catch (final Throwable e) {
			System.out.println( e.getMessage() );
			
			if ( dumpExceptions ) {
				e.printStackTrace();
			}
			
			System.out.println( "--- Additional file operations to be done ---" );
			System.out.println();
			return false;
		}
	}
	
	private boolean checkRecursiveQueries() {
		try {
			testAbsolutePath();
			testTotalSize();
			
			System.out.println( "=== Mark +1: Recursive queries done ===" );
			System.out.println();
			return true;
		} catch (final Throwable e) {
			System.out.println( e.getMessage() );
			
			if ( dumpExceptions ) {
				e.printStackTrace();
			}
			
			System.out.println( "--- Recursive queries to be done ---" );
			System.out.println();
			return false;
		}
	}
	
	private boolean checkSorting() {
		try {
			testMinEntrySize();
			testMaxEntrySize();
			testSortedEntries();
			
			System.out.println( "=== Mark +1: Min, max, sorted entry quieries done ===" );
			System.out.println();
			return true;
		} catch (final Throwable e) {
			System.out.println( e.getMessage() );
			
			if ( dumpExceptions ) {
				e.printStackTrace();
			}
			
			System.out.println( "--- Min, max, sorted entry quieries to be done ---" );
			System.out.println();
			return false;
		}
	}
}
