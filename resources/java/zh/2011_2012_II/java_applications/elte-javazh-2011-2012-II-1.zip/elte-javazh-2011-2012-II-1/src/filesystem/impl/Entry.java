package filesystem.impl;

import filesystem.IEntry;
import filesystem.IFolder;

public abstract class Entry
		implements IEntry {
	
	protected static IFolder root;
	protected IFolder parent;
	protected String name;
	
	protected Entry(final IFolder parent, final String name) {
		this.parent = parent;
		this.name = name;
		if ( parent != null ) {
			parent.add( this );
		}
	}
	
	@Override
	public IFolder getRoot() {
		return root;
	}
	
	@Override
	public String getName() {
		return name;
	}
	
	@Override
	public IFolder getParent() {
		return parent;
	}
	
	@Override
	public void moveTo(final IFolder folder) {
		folder.add( this );
		delete();
	}
	
	@Override
	public void rename(final String newName) {
		name = newName;
	}
	
	@Override
	public void delete() {
		parent.remove( this );
	}
	
	@Override
	public int size() {
		return 0;
	}
	
	@Override
	public String getAbsolutePath() {
		String ret = getName();
		IFolder act = parent;
		
		while ( act != null ) {
			if ( act.isRootFolder() ) {
				ret = act.getName() + ret;
			} else {
				ret = act.getName() + "/" + ret;
			}
			
			act = act.getParent();
		}
		
		return ret;
	}
	
	@Override
	public int compareTo(final IEntry o) {
		return size() - o.size();
	}
}
