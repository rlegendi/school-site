package filesystem.impl;

import filesystem.IFile;
import filesystem.IFolder;

public class File
		extends Entry
		implements IFile {
	
	private final String content;
	
	public File(final IFolder parent, final String name, final String content) {
		super( parent, name );
		this.content = content;
	}
	
	@Override
	public String getContent() {
		return content;
	}
	
	@Override
	public int size() {
		return content.length();
	}
	
	@Override
	public String toString() {
		return name + " [size=" + size() + ", content=" + content + "]";
	}
	
}
