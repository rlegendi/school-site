package filesystem;

public interface IEntry
		extends Comparable<IEntry> {
	
	// 2
	
	public abstract String getName();
	
	public abstract IFolder getParent();
	
	public abstract int size();
	
	public abstract IFolder getRoot();
	
	// +1
	
	public abstract void delete();
	
	public abstract void moveTo(IFolder folder);
	
	public abstract void rename(String newName);
	
	// +1
	
	public abstract String getAbsolutePath();
	
	// +1
	
	public int compareTo(IEntry o);
}
