package filesystem;

public interface IFile extends IEntry {
	
	public abstract String getContent();
	
}
