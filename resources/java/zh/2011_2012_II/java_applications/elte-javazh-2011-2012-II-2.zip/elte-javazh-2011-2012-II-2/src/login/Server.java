package login;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

class User
		implements Comparable<User> {
	private final String name, pass;
	
	public User(String csvData) {
		super();
		
		String[] data = csvData.split( ", " );
		name = data[0];
		pass = data[1];
	}
	
	public User(final String name, final String pass) {
		super();
		this.name = name;
		this.pass = pass;
	}
	
	public String getName() {
		return name;
	}
	
	public String getPass() {
		return pass;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ( ( name == null ) ? 0 : name.hashCode() );
		result = prime * result + ( ( pass == null ) ? 0 : pass.hashCode() );
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj )
			return true;
		if ( obj == null )
			return false;
		if ( getClass() != obj.getClass() )
			return false;
		User other = (User) obj;
		if ( name == null ) {
			if ( other.name != null )
				return false;
		} else if ( ! name.equals( other.name ) )
			return false;
		if ( pass == null ) {
			if ( other.pass != null )
				return false;
		} else if ( ! pass.equals( other.pass ) )
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return name + ", " + pass;
	}
	
	@Override
	public int compareTo(User o) {
		return name.compareTo( o.getName() );
	}
}

public class Server {
	private static final Set<User> users = new HashSet<>();
	
	public static void main(final String[] args) {
		try {
			final ServerSocket server = new ServerSocket( 80 );
			try (Socket s = server.accept();
					BufferedReader br = new BufferedReader( new InputStreamReader( s.getInputStream() ) );
					PrintWriter pw = new PrintWriter( new OutputStreamWriter( s.getOutputStream() ) )) {
				
				String line = null;
				
				while ( ( line = br.readLine() ) != null ) {
					final String[] params = line.split( "\\s+" );
					
					if ( params[0].equals( "register" ) ) {
						register( pw, params[1], params[2] );
					} else if ( params[0].equals( "login" ) ) {
						login( pw, params[1], params[2] );
					} else if ( params[0].equals( "backup" ) ) {
						backup( pw );
					} else if ( params[0].equals( "restore" ) ) {
						restore( pw );
					} else if ( params[0].equals( "listMails" ) ) {
						listMails( pw );
					}
				}
			}
		} catch (final IOException e) {
			e.printStackTrace();
		}
	}
	
	private static void listMails(PrintWriter pw) {
		ArrayList<User> userList = new ArrayList<User>( users );
		Collections.sort( userList );
		
		for (User u : userList) {
			pw.println( u.getName() );
		}
		
		pw.println( "--END--" );
		pw.flush();
	}
	
	private static void restore(PrintWriter pw) {
		users.clear();
		
		try {
			List<String> csv = Files.readAllLines( Paths.get( "backup.txt" ), Charset.defaultCharset() );
			for (String data : csv) {
				users.add( new User( data ) );
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		pw.println( "Backup loaded" );
		pw.flush();
	}
	
	private static void backup(PrintWriter pw) {
		try (PrintWriter fpw = new PrintWriter( "backup.txt" )) {
			for (User u : users) {
				fpw.println( u );
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		pw.println( "Backup created" );
		pw.flush();
	}
	
	private static void login(PrintWriter pw, final String user, final String pass) {
		pw.println( users.contains( new User( user, pass ) ) );
		pw.flush();
	}
	
	private static void register(PrintWriter pw, final String user, final String pass) {
		User u = new User( user, pass );
		users.add( u );
		pw.println( "User registered: " + u );
		pw.flush();
	}
}
