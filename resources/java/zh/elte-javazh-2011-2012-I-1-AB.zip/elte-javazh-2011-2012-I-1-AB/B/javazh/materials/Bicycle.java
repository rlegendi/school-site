package javazh.materials;

public class Bicycle{
	
    public static final String RED = "red";
    public static final String GREEN = "green";
    public static final String BLUE = "blue";
    public static final String YELLOW = "yellow";
    
    private boolean free;
    private final String color;
    private String customer;
    
    public Bicycle(String c){
        color = c;
        free = true;
        customer = "";
    }
    
    public boolean isFree(){
        return free;
    }
    /*
    public boolean reserve(String c){
        if (free){
            free = false;
            customer = c;
        }
        return !free;
    }
    
    public boolean takeBack(){
        boolean takeBack = false;
        if (!free){
            free = true;
            customer = "";
            takeBack = true;
        }
        return takeBack;
    }
    */
    public String getColor(){
        return color;
    }
    
    public String getCustomer(){
        return customer;
    }
    
    public String toString(){
        String c = "nobody";
        if (!customer.equals("")) c = customer;
        return "The "+color+" of bicycle has been lended by "+c+".";
    }

}