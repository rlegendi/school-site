package javazh;

import javazh.materials.*;
import javazh.office.*;
import java.lang.reflect.*;

class LenderTest {

    private static int mark = 1;
    private static Lender l = null;

    public static void main(String[] args) {
        if (mark2()) {
            mark = 2;
        }
        if (mark2() && mark3()) {
            mark = 3;
        }
        if (mark2() && mark3() && mark4()) {
            mark = 4;
        }
        if (mark2() && mark3() && mark4() && mark5()) {
            mark = 5;
        }
        System.out.println("A jegyed = " + mark);
    }

    private static boolean mark2() {
        boolean isRight = false;
        boolean finalized = false;
        try {
            Bicycle b = new Bicycle(Bicycle.RED);
            Class c = b.getClass();
            try {
                Field f = c.getField("color");
                f.set(b, Bicycle.GREEN);
            } catch (NoSuchFieldException ex) {
                finalized = false;
                try {
                    Field field = c.getDeclaredField("color");
                    field.set(b, Bicycle.GREEN);
                } catch (IllegalAccessException e) {
                    finalized = true;
                }
            }
            b.isFree();
            b.getCustomer();
            b.getColor();
            isRight = true;
        } catch (Exception ex) {
            System.out.println("Nem sikerult meg maradektalanul megvalositani a Bicycle osztályt 2-esért!");
        }
        return isRight && finalized;
    }

    private static boolean mark3() {
        boolean isRight = false, finalized = false;
        try {
            l = new Lender(10);
            Class c = l.getClass();
            try {
                Field f = c.getField("bicycles");
                f.set(l, 20);
            } catch (NoSuchFieldException ex) {
                finalized = false;
                try {
                    Field field = c.getDeclaredField("bicycles");
                    field.set(l, 20);
                } catch (IllegalAccessException e) {
                    finalized = true;
                }
            }
            l.addBicycle(new Bicycle(Bicycle.BLUE));
            l.addBicycle(new Bicycle(Bicycle.RED));
            l.addBicycle(new Bicycle(Bicycle.GREEN));
            l.addBicycle(new Bicycle(Bicycle.YELLOW));
            l.addBicycle(new Bicycle(Bicycle.RED));
            l.addBicycle(new Bicycle(Bicycle.BLUE));
            boolean add1 = l.addBicycle(new Bicycle(Bicycle.RED));
            l.addBicycle(new Bicycle(Bicycle.YELLOW));
            l.addBicycle(new Bicycle(Bicycle.GREEN));
            l.addBicycle(new Bicycle(Bicycle.BLUE));
            boolean add2 = l.addBicycle(new Bicycle(Bicycle.BLUE));
            if (l.numberOfFreeBicycles() == 10 && !add2 && add1) {
                isRight = true;
            }
        } catch (Exception ex) {
            System.out.println("Nem sikerult meg maradektalanul megvalositani a Lender osztalyt a 3-asért!");
        }
        return isRight && finalized;
    }

    private static boolean mark4() {
        boolean isRight = false;
        try {
            l = new Lender(10);
            l.addBicycle(new Bicycle(Bicycle.BLUE));
            l.addBicycle(new Bicycle(Bicycle.RED));
            l.addBicycle(new Bicycle(Bicycle.YELLOW));
            l.addBicycle(new Bicycle(Bicycle.YELLOW));
            l.addBicycle(new Bicycle(Bicycle.RED));
            l.addBicycle(new Bicycle(Bicycle.YELLOW));
            l.addBicycle(new Bicycle(Bicycle.YELLOW));
            l.addBicycle(new Bicycle(Bicycle.BLUE));
            boolean rent1 = l.rentBicycle("Kiss Pista", Bicycle.RED);
            boolean rent2 = l.rentBicycle("Kiss Pista", Bicycle.GREEN);
            l.rentBicycle("Kiss Pista", Bicycle.RED);
            l.rentBicycle("P�tty�s Panna", Bicycle.RED);
            l.rentBicycle("Seg�t Elek", Bicycle.BLUE);
            l.rentBicycle("Kiss Pista", Bicycle.YELLOW);
            Bicycle b = new Bicycle(Bicycle.BLUE);
            boolean reserve = b.reserve("Mekk Elek");
            if (rent1 && !rent2 && reserve) {
                isRight = true;
            }
        } catch (Exception ex) {
            System.out.println("Nem sikerult meg maradektalanul megvalositani a Lender osztalyt a 4-esért!");
        }
        return isRight;
    }

    private static boolean mark5() {
        boolean isRight = false;
        try {
            System.out.println(l.toString());
            boolean takeBack1 = l.takeBackBicycle("Kiss Pista");
            System.out.println(l.toString());
            boolean takeBack2 = l.takeBackBicycle("Mekk Elek");
            l.takeBackBicycle("Kiss Pista");
            l.takeBackBicycle("P�tty�s Panna");
            l.takeBackBicycle("Seg�t Elek");
            l.takeBackBicycle("Kiss Pista");
            System.out.println(l.toString());
            Bicycle b = new Bicycle(Bicycle.GREEN);
            System.out.println(b.toString());
            boolean reserve = b.reserve("Mekk Elek");
            System.out.println(b.toString());
            boolean takeBack3 = b.takeBack();
            System.out.println(l.toString());
            if (takeBack1 && !takeBack2 && reserve && takeBack3) {
                isRight = true;
            }
        } catch (Exception ex) {
            System.out.println("Nem sikerult meg maradektalanul megvalositani a Lender osztalyt a 5-ösört!");
        }
        return isRight;
    }

}