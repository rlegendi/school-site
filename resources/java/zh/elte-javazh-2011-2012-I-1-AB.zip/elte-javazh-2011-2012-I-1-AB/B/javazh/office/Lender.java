package javazh.office;

import javazh.materials.Bicycle;

public class Lender{
        
    private Bicycle[] bicycles;
    private int numberOfBicycles;
    
    public Lender(int n){
        bicycles = new Bicycle[n];
        numberOfBicycles = 0;
    }
    
    public boolean addBicycle(Bicycle b){
        if (numberOfBicycles < bicycles.length){
            bicycles[numberOfBicycles] = b;
            numberOfBicycles++;
            return true;
        }
        return false;
    }
    /*
    public boolean rentBicycle(String customer, String color){
        for (int i = 0; i < numberOfBicycles; i++){
            if (bicycles[i].isFree() && bicycles[i].getColor().equals(color)){
                if (bicycles[i].reserve(customer)) return true;
            }
        }
        return false;
    }
    
    public boolean takeBackBicycle(String customer){
        for(int i = 0; i < numberOfBicycles; i++){
            if (bicycles[i].getCustomer().equals(customer)){
                if (bicycles[i].takeBack()) return true;
            }
        }
        return false;
    }
	*/
    public int numberOfFreeBicycles(){
        int nums = 0;
        for (int i = 0; i < numberOfBicycles; i++){
            if (bicycles[i].isFree()) nums++;
        }
        return nums;
    }
    
    public String toString(){
        return "The lender has "+(bicycles.length - numberOfBicycles)+" free place(s) for bicycles, and "+(numberOfBicycles - numberOfFreeBicycles())+" bicycle(s) has/have been lended.";
    }

}