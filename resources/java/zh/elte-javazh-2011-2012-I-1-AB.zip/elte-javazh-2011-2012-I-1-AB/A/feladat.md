Programozás nyelvek (Java)

2011-2012-1, I. Zárthelyi feladat "B csoport"

A feladat leírása|
==================

Egy négyzet alakú, adott méretű falat szeretnénk becsempézni,
kezdetben csak egyféle (adott) színű csempékkel. Később szeretnénk
adott pozíción lévő csempéket más színűre cserléni, vagy esetleg egy
adott mintázat alapján cserélgetni a falunkon a csempéket.

A csempéket (Tile), a falakat (Wall) és a mintákat (Pattern)
reprezentáló osztályok kerüljenek a javazh.tiling csomagba, a
tesztosztályunkat (TilingTest) a javazh csomag fogja tartalmazni.

Feladatok a 2-esért:|
---------------------

A javazh.tiling.Tile osztály létrehozása a következő módon:

>Adattagok: 
- int colour: a csempe színkódját jelöli (a példáinkban ezek csak
  egyjegyű, pozitív számok lesznek)
>Konstruktor:
- Tile(int Colour): létrehoz egy adott színű csempét
>Metódusok:
- int getColour(): visszaadja a csempe színét
- String toString(): visszaadja a csempe String reprezentációját, ami
  a színkód két függőleges vonal között (Pl. 8-as színkódú csempe
  esetén: "|8|")

A javazh.tiling.Wall osztály létrehozása a következő módon:

>Adattagok: 
- Tile[][] tiles: két dimenziós, csempéket tartalmazó tömb, a falat
  reprezentálja 
  Megjegyzés: a fal csempéinek sorszámozása vízszintesen
  és függőlegesen is 0-tól kezdődik
  TODO: ábra?
>Konstruktor:
- Wall(int size, int colour): létrehoz egy size*size-as méretű falat
  úgy, hogy minden mezőbe egy új, a paraméterként megadott színnel
  megegyező színű csempe kerül
>Metódusok:
- Tile[][] getTiles(): visszaadja a csempéket tartalmazó tömböt


Faladatok a 3-asért:|
---------------------

A javazh.tiling.Wall osztály kiegészítése a következő metódusokkal:

- Tile getTile(int x, int y): visszaadja a fal (x,y) pozíción lévő
  csempéjét
- void changeTile(int x, int y, Tile t): a fal (x,y) pozíción lévő
  csempéjének kicserélése a paraméterként megadott csempével
- String toString(): visszaadja a fal String reprezentációját úgy,
  hogy a csempék sorokba és oszlopokba rendezve jelenjenek meg
  Pl. 3*3-as méretű, csak 0-ás színkódú csempéket tartalmazó fal:
       |0||0||0|
       |0||0||0|
       |0||0||0|

Feladatok a 4-esért|
--------------------

A javazh.tiling.Pattern osztály létrehozása a következő módon:

>Adattagjai nincsenek

>Metódus: 

- static boolean isColoured(char pattern, int size, int x, int y): az
  osztály egyetlen, osztályszintű metódusa megadja, hogy egy adott
  méretű mintán az adott pozíció mezője a minta alapján színes-e vagy
  nem
  
  Részletek: a mintát jelölő karakter lehet 'X', 'B' vagy 'C' és ezek
  kisbetűs változatai. Ha másféle karaktert kapunk paraméterként, a
  visszatérési érték false.  

  A példákon 1-es fogja jelölni a színes, 0-ás a nem színes mezőket
  egy 5*5-ös mintán.

  A minták jelentése:
 
 'X' - az adott pozíción lévő mező színes, ha az átlón helyezkedik el.
  Pl. 10001 
      01010
      00100
      10001
      01010 
 'B' (border) - az adott pozíción lévő mező színes, ha a szélső sorok
  vagy oszlopok valamelyikén helyezkedik el.
  Pl. 11111
      10001
      10001
      10001
      11111 
'C' (cross) - az adott pozíción lévő mező színes, ha a középső soron
  vagy oszlopon helyezkedik el. Ha a méret páros szám, akkor a
  közepétől 1-el lefelé, ill. jobbra lévő sor és oszlop színes.
  Pl. 00100 
      00100
      11111
      00100
      00100

Feladat a 5-ösért|
------------------

A javazh.tiling.Wall osztály kiegészítése a következő metódussal:

- void usePattern(char pattern, int colour): a falon az adott minta
  alapján cserélje le a csempéket új, a paraméterben megadott színű
  csempére (használd a Pattern osztály isColoured metódusát annak
  eldöntésére, hogy mely csempéket kell lecserélni)


Beadás módja|
=============
???

KOJQAAI                      - EHA
+---javazh                    
    +---tiling
    |   \---                 - forrásállományok
    \---TilingTest.java
