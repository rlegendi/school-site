package javazh;

import javazh.tiling.*;
import java.util.Arrays;

public class TilingTest {

    public static byte mark = 1;

    public static void writeMark() {
        System.out.printf("=======================%n" +
                          "======= MARK: %d =======%n" +
                          "=======================%n", 
                          mark);
    }
    
    public static void writeOut(int[][] t) {
        for (int i=0; i<t.length; i++) {
            for (int j=0; j<t.length; j++) {
                System.out.print(t[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void check(final boolean passed,final String msg, final String cl) {
        if (!passed) {
            System.out.printf("FAILURE: %s (class: %s)%n",msg,cl);
            writeMark();
            System.exit(1);
        }
    }

    public static void testForMark2() {
        //Testing Tile class...
        Tile t = new Tile(3);
        check(t.getColour() == 3, "Invalid getColour()", "Tile");
        check(t.toString().equals("|3|"), "Invalid toString()", "Tile");

        //Testing constructor and getTiles() of Wall...
        Tile[][] tiles1 = new Wall(3,0).getTiles();
        Tile[][] tiles2 = new Wall(1,5).getTiles();
        int[][] tc1 = new int[3][3];
        int[][] tc2 = {{tiles2[0][0].getColour()}};
        for (int i=0; i<3; i++)
            for (int j=0; j<3; j++)
                tc1[i][j] = tiles1[i][j].getColour();
        check(Arrays.deepEquals(tc1,
                                new int[][] {{0,0,0},{0,0,0},{0,0,0}}),
              "Invalid constructor or getTiles()", "Wall");
        check(Arrays.deepEquals(tc2,
                                new int[][] {{5}}),
              "Invalid constructor or getTiles()", "Wall");

        mark++;
    } 

    public static void testForMark3() {
        //Testing getTile() and changeTile(...) of Wall...
        Wall w = new Wall(3,1);
        check(w.getTile(0,0).getColour() == 1 && w.getTile(2,2).getColour() == 1,
              "Invalid getTile()", "Wall");
        
        w.changeTile(1,2, new Tile(3));
        check(w.getTile(1,2).getColour() == 3,
              "changeTile method does not change the Tile on the Wall properly", "Wall");

        //Testing toString() of Wall...
        check(w.toString().equals(String.format("|1||1||1|%n" + 
                                                "|1||1||3|%n" +
                                                "|1||1||1|%n")) 
              //there is a newline after the last row 
              ||
              w.toString().equals(String.format("|1||1||1|%n" +
                                                "|1||1||3|%n" +
                                                "|1||1||1|")), 
              //there is no newline after the last row
              "Invalid toString()", "Wall");

        mark++;
    }
     
    //helper function for testForMark4
    public static String faliureString(char pattern, int size, int i, int j, boolean b) {
        return String.format("(%d,%d) field of a pattern '%c' with size %d should be %s.",
                             i, j, pattern, size, b?"coloured":"not coloured");
        }

    public static void testForMark4() {

        //Testing isCOloured(...) of Pattern...
        
        //'X' pattern
        check(Pattern.isColoured('X',5,4,4), faliureString('X',5,4,4,true), "Wall");
        check(Pattern.isColoured('X',5,1,3), faliureString('X',5,1,3,true), "Wall");
        check(Pattern.isColoured('X',8,5,2), faliureString('X',8,5,2,true), "Wall");
        check(!Pattern.isColoured('X',5,1,4), faliureString('X',5,1,4,false), "Wall");
        
        //'B' pattern
        check(Pattern.isColoured('B',5,0,2), faliureString('B',5,0,2,true), "Wall");
        check(Pattern.isColoured('B',5,3,0), faliureString('B',5,3,0,true), "Wall");
        check(Pattern.isColoured('B',8,7,2), faliureString('B',8,7,2,true), "Wall");
        check(Pattern.isColoured('B',5,1,4), faliureString('B',5,1,4,true), "Wall");
        check(!Pattern.isColoured('B',5,1,1), faliureString('B',5,1,1,false), "Wall");
        check(!Pattern.isColoured('B',5,3,3), faliureString('B',5,3,3,false), "Wall");
        
        //'C' pattern
        check(Pattern.isColoured('C',5,1,2), faliureString('C',5,1,2,true), "Wall");
        check(Pattern.isColoured('C',5,2,3), faliureString('C',5,2,3,true), "Wall");
        check(Pattern.isColoured('C',8,4,2), faliureString('C',8,4,2,true), "Wall");
        check(Pattern.isColoured('C',8,0,4), faliureString('C',8,0,4,true), "Wall");
        check(!Pattern.isColoured('C',5,1,1), faliureString('C',5,1,1,false), "Wall");
        check(!Pattern.isColoured('C',5,3,3), faliureString('C',5,3,3,false), "Wall");

        mark++;
    }

    //helper function for testForMark5
    public static int[][] getTilesColour(Wall w) {
        Tile[][] t = w.getTiles();
        int size = t.length;
        int[][] c = new int[size][size];
        for (int i=0; i<size; i++) 
            for (int j=0; j<size; j++)
                c[i][j] = t[i][j].getColour();
        return c;
    }

    public static void testForMark5() {
        //Testing usePattern(...) of Wall...
        Wall w = new Wall(5,0);
        w.usePattern('X', 8);
        int[][] c = getTilesColour(w);
        check(Arrays.deepEquals(c,
                                new int[][] {
                                    {8,0,0,0,8},
                                    {0,8,0,8,0},
                                    {0,0,8,0,0},
                                    {0,8,0,8,0},
                                    {8,0,0,0,8}}),
              "Invalid usePattern method with 'X' pattern",
              "Wall");

        w.usePattern('B', 3);
        c = getTilesColour(w);
        check(Arrays.deepEquals(c,
                                new int[][] {
                                    {3,3,3,3,3},
                                    {3,8,0,8,3},
                                    {3,0,8,0,3},
                                    {3,8,0,8,3},
                                    {3,3,3,3,3}}),
              "Invalid usePattern method with 'B' pattern after 'X' pattern",
              "Wall");

        mark++;
    }

    public static void main(String[] args) {
    
        testForMark2();
        testForMark3();
        testForMark4();
        testForMark5();

        writeMark();
    }

}