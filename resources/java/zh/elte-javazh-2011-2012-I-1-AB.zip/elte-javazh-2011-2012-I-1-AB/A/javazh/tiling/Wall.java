package javazh.tiling;

public class Wall {

    private int size;
    private Tile[][] tiles;

    //2
    public Wall(int n, int colour) {
        size = n;
        tiles = new Tile[n][n];
        for (int i=0; i<n; i++) {
            for (int j=0; j<n; j++) {
                tiles[i][j] = new Tile(colour);
            }
        }
    }
   
    //2
    public Tile[][] getTiles() {
        return tiles;
    }

    //3
    public Tile getTile(int i, int j) {
        return tiles[i][j];
    }

    //3
    public void changeTile(int i, int j, Tile t) {
        tiles[i][j] = t;
    }
    
    //3
    public String toString() {
        String s = "";
        for (int i=0; i<size; i++) {
            for (int j=0; j<size; j++) {
                s += tiles[i][j];
            }
            s += "\n";
        }
        return s;
    }

    //5
    public void usePattern(char pattern, int colour) {
        for (int i=0; i<size; i++) {
            for (int j=0; j<size; j++) {
                if (Pattern.isColoured(pattern, size, i, j)) 
                    changeTile(i,j,new Tile(colour));
            }
        }
    }

}