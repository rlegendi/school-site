package javazh.tiling;

//2
public class Tile {

    private int colour;

    public Tile(int colour) {
        this.colour = colour;
    }
    
    public int getColour() {
        return colour;
    }

    public String toString() {
        return "|" + colour + "|";
    }    

}