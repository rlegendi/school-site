package javazh.tiling;

public class Pattern {
    
    //4
    public static boolean isColoured(char pattern, int size, int i, int j) {
        pattern = Character.toUpperCase(pattern);
        return 
            pattern == 'X' &&  
                (i == j || i + j == size-1) ||
            pattern == 'B' && 
                (i == 0 || i == (size-1) || j == 0 || j == (size-1)) ||
            pattern == 'C' && 
                (i == size/2 || j == size/2);

        /* vagy:
        switch (pattern) {
        case 'O': break;
        case 'X': 
            if (i == j || i + j == size-1)
                return true; 
            break;
        case 'B':
            if (i == 0 || i == (size-1) || j == 0 || j == (size-1))
                return true;
            break;
        case 'C':
            if (i == size/2 || j == size/2)
                return true;
            break;
        default: break;
        }
        return false; */
    }
}