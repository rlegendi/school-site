package media.data;

public class AMedium
		implements Cloneable {
	protected String title;
	protected int copies;
	
	protected AMedium(final String title, final int copies) {
		super();
		this.title = title;
		this.copies = copies;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getTitle() {
		return title;
	}
	
	public int getCopies() {
		return copies;
	}
	
	// ======================================================================================================================
	// === Uj szolgaltatasok ================================================================================================
	
	/**
	 * Az {@link Object} altal definialt fuggveny lathatova tetelere szolgal. Eloadason targyaltatok.
	 */
	@Override
	public Object clone()
			throws CloneNotSupportedException {
		return super.clone();
	}
}
