package media.data;

public class Book
		extends AMedium {
	protected String author;
	
	public Book(final String title, final int copies, final String author) {
		super( title, copies );
		this.author = author;
	}
	
	public String getAuthor() {
		return author;
	}
	
	@Override
	public String toString() {
		return "Book [author=" + author + ", title=" + title + ", copies=" + copies + "]";
	}
	
}
