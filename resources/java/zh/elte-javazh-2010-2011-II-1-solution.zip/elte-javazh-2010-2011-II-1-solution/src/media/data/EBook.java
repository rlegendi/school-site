package media.data;

import java.util.Collection;
import java.util.Collections;

// TODO Book leszarmazott legyen
public class EBook
		extends Book {
	protected String URL;
	
	public EBook(String title, int copies, String author) {
		super( title, copies, author );
	}
	
	public String getTitle() {
		return title;
	}
	
	public int getCopies() {
		return copies;
	}
	
	public String getAuthor() {
		return author;
	}
	
	public String getURL() {
		return URL;
	}
	
	public static Collection<EBook> getDefaultEBookCollection() {
		// TODO Minimum egy elemet visszaadni!
		return Collections.singleton( new EBook( "A", 10, "B" ) );
	}
}
