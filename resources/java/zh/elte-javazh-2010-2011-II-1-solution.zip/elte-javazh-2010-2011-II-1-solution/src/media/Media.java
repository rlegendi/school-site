package media;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

import media.data.Rating;

public class Media {
	private final ArrayList<Rating> ratings = new ArrayList<Rating>();
	
	public int getRatingsNumber() {
		return ratings.size();
	}
	
	public Collection<Rating> getRatings() {
		return Collections.unmodifiableCollection( ratings );
	}
	
	public void addRating(final Rating rating) {
		ratings.add( rating );
	}
	
	public void modifyRating(final String id, final int score) {
		final int idx = ratings.indexOf( Rating.createDummy( id ) );
		ratings.get( idx ).setScore( score );
	}
	
	public void deleteRating(final String id) {
		final int idx = ratings.indexOf( Rating.createDummy( id ) );
		ratings.remove( idx );
	}
	
	public Rating getWorstRating() {
		return Collections.min( ratings );
	}
	
	public Rating getBestRating() {
		return Collections.max( ratings );
	}
	
	// ======================================================================================================================
	// === New Stuff Here ===================================================================================================
	
	/**
	 * A rendezett <code>score</code> ertekekbol visszaadja azt, amelyik kozepen van (paratlan elemszam eseten lefele
	 * kerekitjuk a felezett erteket).
	 */
	public int getMedianScoreOfRatings() {
		final int[] arr = new int[ratings.size()];
		
		for (int i = 0; i < arr.length; ++i) {
			arr[i] = ratings.get( i ).getScore();
		}
		
		Arrays.sort( arr );
		return arr[arr.length / 2];
	}
	
	/**
	 * Vegig kell menni a tarolt ertekeleseken, es nagybetusiteni kell a cimeket a kovetkezokeppen: az elso karaktert
	 * nagybetusre csereljuk, az osszes tobbit kicsire.
	 */
	public void fixTitles() {
		for (final Rating rating : ratings) {
			final String oldTitle = rating.getMedium().getTitle();
			final String newTitle = Character.toUpperCase( oldTitle.charAt( 0 ) ) + oldTitle.substring( 1 ).toLowerCase();
			
			rating.getMedium().setTitle( newTitle );
		}
	}
	
}
