package media.data;

import java.util.Collection;
import java.util.Collections;

// TODO Book leszarmazott legyen
public class EBook {
	protected String title;
	protected int copies;
	protected String author;
	protected String URL;
	
	public String getTitle() {
		return title;
	}
	
	public int getCopies() {
		return copies;
	}
	
	public String getAuthor() {
		return author;
	}
	
	public String getURL() {
		return URL;
	}
	
	public static Collection<EBook> getDefaultEBookCollection() {
		// TODO Minimum egy elemet visszaadni!
		return Collections.emptyList();
	}
}
