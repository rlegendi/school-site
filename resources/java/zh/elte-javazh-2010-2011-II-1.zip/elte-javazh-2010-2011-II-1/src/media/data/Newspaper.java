package media.data;

public class Newspaper
		extends AMedium {
	private String editor;
	
	public Newspaper(final String title, final int copies, final String editor) {
		super( title, copies );
		this.editor = editor;
	}
	
	public String getEditor() {
		return editor;
	}
	
	@Override
	public String toString() {
		return "Newspaper [editor=" + editor + ", title=" + title + ", copies=" + copies + "]";
	}
}
