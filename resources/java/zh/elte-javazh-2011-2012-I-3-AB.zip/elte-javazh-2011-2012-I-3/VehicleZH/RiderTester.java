import java.util.ArrayList;
import java.util.List;

import test.BuilderTest;
import test.GarageTest;
import test.IOTest;
import test.Test;
import test.VehicleTest;


public class RiderTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<Test> tests=new ArrayList<Test>();
		tests.add(new VehicleTest());
		tests.add(new GarageTest());
		tests.add(new BuilderTest());
		tests.add(new IOTest());
		int mark=1;
		for(Test test:tests) {
			if(test.test()) {
				++mark;
			}
		}
		System.out.println("A jegyed legfeljebb ennyi, vagy csak ennel kevesebb lehet: "+mark);
		System.out.println("A jegyed korant sem biztos, hogy eleri ezt a felso hatart!");
	}

}
