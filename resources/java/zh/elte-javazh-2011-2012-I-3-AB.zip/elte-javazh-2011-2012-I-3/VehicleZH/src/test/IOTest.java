package test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import zh.Car;
import zh.Motor;
import zh.Vehicle;
import zh.VehicleIO;

public class IOTest implements Test {

	@Override
	public boolean test() {
		boolean isRight = true;

		Vehicle opel = new Car("Opel");
		Vehicle mercedes = new Car("Mercedes");

		Vehicle yamaha = new Motor("Yamaha");
		Vehicle harley = new Motor("Harley");

		List<Vehicle> vehicles = new ArrayList<Vehicle>();

		vehicles.add(yamaha);
		vehicles.add(opel);
		vehicles.add(mercedes);
		
		try {
			File lista = new File("lista.txt");
			if (lista.exists()) {
				if (!lista.delete()) {
					System.err.println("A lista.txt nem torolheto!");
					isRight = false;
				}
			}
			if (!lista.createNewFile()) {
				System.err.println("A lista.txt nem hozhato letre!");
				isRight = false;
			}
			long previousSize = lista.length();
			VehicleIO.save("lista.txt", vehicles);
			if (lista.length() == previousSize) {
				System.err
						.println("Nem nott a file merete. Lezarod a file-t olvasas utan?");
				isRight = false;
			}
		} catch (FileNotFoundException e) {
			isRight = false;
			System.err.println("Miert nem talalom a file-t?");
			e.printStackTrace();
		} catch (IOException e) {
			isRight = false;
			System.err.println("IOExcpetion kelettkezett file iraskor.");
			e.printStackTrace();
		}

		try {
			File renamed = new File("renamed.txt");
			if (renamed.exists() && !renamed.delete()) {
				System.err.println("A renamed.txt letezik, de nem torolheto!");
				isRight = false;
			}
			File lista = new File("lista.txt");
			List<Vehicle> readedList = VehicleIO.load("lista.txt");
			if (!lista.renameTo(new File("renamed.txt"))) {
				System.err
						.println("Miert nem tudom atnevezni a lista.txt-t? Lezartad a file-t?");
				isRight = false;
			}
			if (!renamed.delete()) {
				System.err.println("Nem tudom torolni a renamed.txt-t.");
				isRight = false;
			}
			if (readedList.size() != 3) {
				System.err
						.println("Hibas a load(String), vagy a save(String, List<SpaceShip>)");
				System.err.println("Nem megfelelo a beolvasott lista hossza.");
				System.err.println("Elvart eredmeny: 3");
				System.err.println("Kapott eredmeny: " + readedList.size());
				isRight = false;
			}

			if (!readedList.contains(yamaha)
					|| !readedList.contains(opel)
					|| !readedList.contains(mercedes)
					|| readedList.contains(harley)) {
				System.err
						.println("Nem a megfelelo elemeket tartalmazza a beolvasott lista");
				isRight = false;
			}
		} catch (IOException e) {
			System.err.println("Mier lepett fel IOException?");
			isRight = false;
			e.printStackTrace();
		}

		return isRight;
	}

}
