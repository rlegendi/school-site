package test;

public interface Test {

	public boolean test();
	
}
