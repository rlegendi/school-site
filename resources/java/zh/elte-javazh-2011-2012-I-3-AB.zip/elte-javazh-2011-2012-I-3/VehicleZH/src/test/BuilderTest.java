package test;

import zh.Builder;
import zh.Car;
import zh.Motor;
import zh.Vehicle;

public class BuilderTest implements Test {

	@Override
	public boolean test() {
		boolean isRight=true;
		
		Vehicle motor=new Motor("Yamaha");
		Vehicle car=new Car("Opel");
		Vehicle v=motor;
		String s=Builder.fromVehicle(v);
		if(!s.equals("Yamaha:motor")) {
			System.err.println("Rossz a fromVehicle(Vehicle)");
			System.err.println("Elvart: Yamaha:motor");
			System.err.println("Kapott: "+s);
			isRight=false;
		}
		
		v=car;
		s=Builder.fromVehicle(v);
		if(!s.equals("Opel:car")) {
			System.err.println("Rossz a fromVehicle(Vehicle)");
			System.err.println("Elvart: Opel:car");
			System.err.println("Kapott: "+s);
			isRight=false;
		}
		
		s="";
		try{
			v=Builder.fromString(s);
			System.err.println("Ures Stringre a Builder.fromString(String) dobjon IllegalArgumentException-t!");
			System.err.println("A bejovo String: "+s);
			isRight=false;
		} catch (IllegalArgumentException iae) {
			
		}
		
		s="Yamaha:motor:hat ez meg mi?";
		try{
			v=Builder.fromString(s);
			System.err.println("Nem 2 elemu Stringre a Builder.fromString(String) dobjon IllegalArgumentException-t!");
			System.err.println("A bejovo String: "+s);
			isRight=false;
		} catch (IllegalArgumentException iae) {
			
		}
		
		s=":motor";
		try{
			v=Builder.fromString(s);
			System.err.println("Markatlan jarmure Builder.fromString(String) dobjon IllegalArgumentException-t!");
			System.err.println("A bejovo String: "+s);
			isRight=false;
		} catch (IllegalArgumentException iae) {
			
		}
		
		s="Yamaha:kutya";
		try{
			v=Builder.fromString(s);
			System.err.println("Ha tipus nem motor vagy car, a Builder.fromString(String) dobjon IllegalArgumentException-t!");
			System.err.println("A bejovo String: "+s);
			isRight=false;
		} catch (IllegalArgumentException iae) {
			
		}
		
		s="Hyundai:motor";
		try{
			v=Builder.fromString(s);
			if(!(v instanceof Motor)) {
				System.err.println("Rossz tipusu jarmuvet epetett a builder");
				System.err.println("A bejovo String: "+s);
				isRight=false;
			}
			if(!v.getBrand().equals("Hyundai")) {
				System.err.println("Rossz markanevu jarmuvet epetett a builder");
				System.err.println("A bejovo String: "+s);
				isRight=false;
			}
		} catch (IllegalArgumentException iae) {
			System.err.println("Helyes Stringre a Builder.fromString(String) NE dobjon IllegalArgumentException-t!");
			System.err.println("A bejovo String: "+s);
			isRight=false;
			iae.printStackTrace();
		}
		
		s="Hyundai:car";
		try{
			v=Builder.fromString(s);
			if(!(v instanceof Car)) {
				System.err.println("Rossz tipusu jarmuvet epetett a builder");
				System.err.println("A bejovo String: "+s);
				isRight=false;
			}
			if(!v.getBrand().equals("Hyundai")) {
				System.err.println("Rossz markanevu jarmuvet epetett a builder");
				System.err.println("A bejovo String: "+s);
				isRight=false;
			}
		} catch (IllegalArgumentException iae) {
			System.err.println("Helyes Stringre a Builder.fromString(String) NE dobjon IllegalArgumentException-t!");
			System.err.println("A bejovo String: "+s);
			isRight=false;
			iae.printStackTrace();
		}
		
		
		return isRight;
	}

}
