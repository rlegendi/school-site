package test;

import java.util.List;

import zh.Car;
import zh.Garage;
import zh.Motor;
import zh.Vehicle;

public class GarageTest implements Test {

	@Override
	public boolean test() {
		boolean isRight = true;

		Garage garage = new Garage(8);

		if (garage.getCapacity() != 8) {
			System.err.println("Rossz a Garage.getCapacity()");
			isRight = false;
		}

		if (garage.getFreeSpace() != 8) {
			System.err.println("Rossz a Garage.getFreeSpace()");
			isRight = false;
		}

		if (garage.getTakenPlace() != 0) {
			System.err.println("Rossz a Garage.getTakenPlace()");
			isRight = false;
		}

		Vehicle opel = new Car("Opel");
		Vehicle mercedes = new Car("Mercedes");

		Vehicle yamaha = new Motor("Yamaha");
		Vehicle harley = new Motor("Harley");

		garage.add(opel);
		garage.add(yamaha);

		if (garage.getCapacity() != 8) {
			System.err
					.println("Rossz a Garage.getCapacity() elemek hozzadasa utan");
			isRight = false;
		}

		if (garage.getFreeSpace() != 2) {
			System.err
					.println("Rossz a Garage.getFreeSpace() elemek hozzadasa utan");
			isRight = false;
		}

		if (garage.getTakenPlace() != 6) {
			System.err
					.println("Rossz a Garage.getTakenPlace() elemek hozzadasa utan");
			isRight = false;
		}

		if (garage.isParkingHere(mercedes)) {
			System.err
					.println("Rossz az isParkingHere() Car-okra, az is itt parkol, ami nem is!");
			isRight = false;
		}

		if (!garage.isParkingHere(opel)) {
			System.err
					.println("Rossz az isParkingHere() Car-okra, nem talalt egy objektumot!");
			isRight = false;
		}

		garage.add(mercedes);

		if (garage.isParkingHere(mercedes)) {
			System.err
					.println("Rossz az add() Car-okra, ha nem fer el, ne adjon hozza!");
			isRight = false;
		}

		if (!garage.isParkingHere(yamaha)) {
			System.err
					.println("Rossz az isParkingHere() Motor-okra, nem talalt egy objektumot!");
			isRight = false;
		}

		garage.remove(yamaha);

		if (garage.isParkingHere(yamaha)) {
			System.err
					.println("Rossz az isParkingHere() Motor-okra, az is itt parkol, ami nem is!");
			isRight = false;
		}
		
		if (garage.isParkingHere(yamaha)) {
			System.err
					.println("Rossz az remove(Vehcile) Motor-okra, nem vett ki egy objektumot!");
			isRight = false;
		}
		
		if(garage.getCapacity()!=8) {
			System.err.println("Rossz a getCapacity() remove() utan");
			isRight=false;
		}

		if (garage.getFreeSpace() != 4) {
			System.err
					.println("Rossz a Garage.getFreeSpace() remove() utan");
			isRight = false;
		}

		if (garage.getTakenPlace() != 4) {
			System.err
					.println("Rossz a Garage.getTakenPlace() remove utan");
			isRight = false;
		}
		
		garage=new Garage(12);
		
		garage.add(opel);
		garage.add(yamaha);
		garage.add(harley);
		garage.add(mercedes);
		
		garage.remove(yamaha);
		garage.remove(mercedes);
		
		List<Vehicle> vehicles=garage.getVehicles();
		
		if(vehicles.size()!=2) {
			System.err.println("A getVehicles() nem jo hosszusagu listt adott vissza");
			isRight=false;
		}
		
		if(vehicles.contains(yamaha)||vehicles.contains(mercedes)) {
			System.err.println("A getVehicles() olyan listat adott vissza, mely folos elemeket tartalmaz");
			isRight=false;
		}
		
		if(!(vehicles.contains(opel))||!(vehicles.contains(harley))) {
			System.err.println("A getVehicles() nem tartalmaz minden szukseges elemet");
			isRight=false;
		}
		
		return isRight;
	}

}
