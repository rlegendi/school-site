package test;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.PriorityQueue;

import zh.Car;
import zh.Motor;
import zh.Vehicle;

public class VehicleTest implements Test {

	@Override
	public boolean test() {
		boolean isRight = true;
		try {
			Field tires = (Vehicle.class).getDeclaredField("tires");
			if (!Modifier.isFinal(tires.getModifiers())) {
				System.err.println("A Vehicle.tires nem final!");
				isRight = false;
			}
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			System.err.println("Nincs tires nevu final mezoje a Vehciles-nek!");
			isRight = false;
			e.printStackTrace();
		}

		Vehicle v = null;

		Vehicle motor = new Motor("Hyundai");
		v = motor;
		if (v.getTires() != 2) {
			System.err.println("A motorok 2 kerekuek!");
			isRight = false;
		}

		if (!v.getBrand().equals("Hyundai")) {
			System.err
					.println("Nem jo a Motor konstruktora, vagy a getBrand()");
			isRight = false;
		}

		Vehicle car = new Car("Hyundai");
		v = car;
		if (v.getTires() != 4) {
			System.err.println("Az autok 4 kerekuek!");
			isRight = false;
		}

		if (!v.getBrand().equals("Hyundai")) {
			System.err.println("Nem jo a Car konstruktora, vagy a getBrand()");
			isRight = false;
		}

		v = motor;
		try {
			if (v.equals(null)) {
				System.err
						.println("Hogy lenne egy Motor egyenlo egy null-al?!");
				isRight = false;
			}
		} catch (NullPointerException npe) {
			System.err.println("A Motor equals-a elszall null-ra");
			isRight = false;
			npe.printStackTrace();
		}

		try {
			if (v.equals(new Integer(10)) || v.equals(new Boolean(true))
					|| v.equals(new PriorityQueue<String>())) {
				System.err
						.println("Hogy lenne egy Motor egyenlo valamivel, ami nem jarmu?");
				isRight = false;
			}
		} catch (ClassCastException cce) {
			System.err
					.println("Tipusellenorzes hol marad a Motor equals()-abol?");
			isRight = false;
		}

		v = car;
		try {
			if (v.equals(null)) {
				System.err.println("Hogy lenne egy Car egyenlo egy null-al?!");
				isRight = false;
			}
		} catch (NullPointerException npe) {
			System.err.println("A Car equals-a elszall null-ra");
			isRight = false;
			npe.printStackTrace();
		}

		try {
			if (v.equals(new Integer(10)) || v.equals(new Boolean(true))
					|| v.equals(new PriorityQueue<String>())) {
				System.err
						.println("Hogy lenne egy Car egyenlo valamivel, ami nem jarmu?");
				isRight = false;
			}
		} catch (ClassCastException cce) {
			System.err
					.println("Tipusellenorzes hol marad a Car equals()-abol?");
			isRight = false;
		}

		if(motor.equals(car)) {
			System.err.println("Egy Motor nem Car!");
			isRight=false;
		}
		
		if(car.equals(motor)) {
			System.err.println("Egy Car nem Motor!");
			isRight=false;
		}
		
		Vehicle yamaha=new Motor("Yamaha");
		Vehicle opel=new Car("Opel");
		
		if(motor.equals(yamaha)) {
			System.err.println("A Motor-ok egyenloek eltero marka eseten?!");
			isRight=false;
		}
		
		if(car.equals(opel)) {
			System.err.println("A Car-ok egyenloek eltero marka eseten?!");
			isRight=false;
		}
		
		if(!car.equals(new Car("Hyundai"))) {
			System.err.println("A Car nem ismeri fel az azonos objektumot!");
			isRight=false;
		}
		
		if(!motor.equals(new Motor("Hyundai"))) {
			System.err.println("A Motor nem ismeri fel az azonos objektumot!");
			isRight=false;
		}
		
		return isRight;
	}

}
