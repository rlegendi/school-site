package zh;

import java.util.ArrayList;
import java.util.List;

public class Garage {

	private List<Vehicle> vehicels=new ArrayList<Vehicle>();
	private int capacity;
	
	public Garage(int capacity) {
		this.capacity=capacity;
	}
	
	public int getTakenPlace() {
		int sum=0;
		for(Vehicle v:vehicels) {
			sum+=v.getTires();
		}
		return sum;
	}
	
	public int getFreeSpace() {
		return capacity-getTakenPlace();
	}
	
	public int getCapacity() {
		return capacity;
	}
	
	public void add(Vehicle v) {
		if(getFreeSpace() >=v.getTires()) {
			vehicels.add(v);
		}
	}
	
	public void remove(Vehicle v)  {
		vehicels.remove(v);
	}
	
	public boolean isParkingHere(Vehicle v) {
		return vehicels.contains(v);
	}
	
	public List<Vehicle> getVehicles() {
		return vehicels;
	}
	
}
