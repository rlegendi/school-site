package zh;

public class Builder {

	public static Vehicle fromString(String s) {
		String[] pieces = s.split(":");
		if (pieces.length != 2)
			throw new IllegalArgumentException("Nem ket tagbol allo String: "
					+ s);
		if (pieces[0].length() < 1)
			throw new IllegalArgumentException("Nincs markatlan jarmu: " + s);
		if (!pieces[1].equals("motor") && !pieces[1].equals("car"))
			throw new IllegalArgumentException("Se nem motor, se nem auto: "
					+ s);
		return pieces[1].equals("motor") ? new Motor(pieces[0]) : new Car(
				pieces[0]);
	}

	public static String fromVehicle(Vehicle v) {
		return v.getBrand() + ":" + ((v.getTires() == 2) ? "motor" : "car");
	}

}
