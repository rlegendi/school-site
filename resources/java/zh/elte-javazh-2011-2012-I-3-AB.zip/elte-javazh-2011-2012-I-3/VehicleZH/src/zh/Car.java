package zh;

public class Car extends Vehicle {

	public Car(String brand) {
		super(4);
		this.brand=brand ;
	}
	
}
