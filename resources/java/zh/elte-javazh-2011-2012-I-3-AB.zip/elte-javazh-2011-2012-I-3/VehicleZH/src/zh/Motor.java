package zh;

public class Motor extends Vehicle {
	
	public Motor(String brand) {
		super(2);
		this.brand=brand;
	}

}
