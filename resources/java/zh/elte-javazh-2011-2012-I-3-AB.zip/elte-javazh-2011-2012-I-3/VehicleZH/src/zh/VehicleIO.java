package zh;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class VehicleIO {
	
	public static void save(String fn, List<Vehicle> vehicles) throws FileNotFoundException {
		PrintWriter pw=new PrintWriter(new File(fn));
		for(Vehicle v: vehicles) {
			pw.println(Builder.fromVehicle(v));
		}
		pw.close();
	}
	
	public static List<Vehicle> load(String fn) throws IOException {
		List<Vehicle> result=new ArrayList<Vehicle>();
		BufferedReader br=new BufferedReader(new FileReader(new File(fn)));
		String line=null;
		while((line=br.readLine())!=null) {
			result.add(Builder.fromString(line));
		}
		br.close();
		return result;
	}

}
