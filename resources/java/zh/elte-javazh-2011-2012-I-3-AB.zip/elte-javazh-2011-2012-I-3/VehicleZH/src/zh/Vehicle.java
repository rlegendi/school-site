package zh;

public abstract class Vehicle {

	protected final int tires;
	protected String brand;

	public Vehicle(int tires) {
		this.tires = tires;
	}

	public int getTires() {
		return tires;
	}

	public String getBrand() {
		return brand;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null)
			return false;
		if (this.getClass() != o.getClass())
			return false;
		Vehicle v = (Vehicle) o;
		return (v.brand.equals(brand) && tires == v.tires);
	}

	@Override
	public int hashCode() {
		return brand.hashCode();
	}

}
