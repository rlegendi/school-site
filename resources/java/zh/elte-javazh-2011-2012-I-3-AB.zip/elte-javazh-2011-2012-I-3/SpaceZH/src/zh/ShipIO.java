package zh;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class ShipIO {
	
	public static void save(String fn, List<SpaceShip> ships) throws FileNotFoundException {
		PrintWriter pw = new PrintWriter(fn);
		for(SpaceShip ss:ships) {
			pw.println(Converter.shipToString(ss));
		}
		pw.close();
	}

	public static List<SpaceShip> load(String fn) throws IOException {
		List<SpaceShip> ships=new ArrayList<SpaceShip>();
		BufferedReader br=new BufferedReader(new FileReader(fn));
		String line=null;
		while((line=br.readLine())!=null) {
			ships.add(Converter.stringToShip(line));
		}
		br.close();
		return ships;
	}
	
}
