package zh;

public class SpaceShip implements Comparable<SpaceShip> {

	private String name;
	private int power;

	public SpaceShip(String name, int power) {
		this.name = name;
		this.power = power;
	}

	public int getPower() {
		return power;
	}

	public void improve(int power) {
		this.power += power;
	}

	public String getName() {
		return name;
	}

	@Override
	public int compareTo(SpaceShip ss) {
		return (int) Math.signum(power-ss.power);
	}

	@Override
	public boolean equals(Object o) {
		if (o == null)
			return false;
		if (this.getClass() != o.getClass())
			return false;
		SpaceShip ss = (SpaceShip) o;
		if (ss.power != power)
			return false;
		if (!ss.name.equals(name))
			return false;
		return true;
	}

	@Override
	public String toString() {
		//return name + "{" + power + "}";
		return name+":"+power;
	}

	@Override
	public int hashCode() {
		return power;
	}

}
