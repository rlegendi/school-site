package zh;

public class Converter {

	public static String shipToString(SpaceShip ss) {
		return ss.toString();
	}

	public static SpaceShip stringToShip(String s) {
		//String st = s.replace('{', '\t').replace('}', ' ');
		String[] pieces = s.split(":");
		if (pieces.length != 2)
			throw new IllegalArgumentException(
					"Ships name should have two parts");
		int power = Integer.parseInt(pieces[1]);
		if (power < 1)
			throw new IllegalArgumentException(
					"Ships power should be more than 0");
		return new SpaceShip(pieces[0], power);
	}

}
