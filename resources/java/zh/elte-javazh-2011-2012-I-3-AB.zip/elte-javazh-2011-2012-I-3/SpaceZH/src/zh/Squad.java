package zh;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

public class Squad {

	private PriorityQueue<SpaceShip> ships = new PriorityQueue<SpaceShip>();
	
	public void add(SpaceShip ss) {
		ships.add(ss);
	}
	
	public void remove(SpaceShip ss) {
		ships.remove(ss);
	}
	
	public List<SpaceShip> getList() {
		PriorityQueue<SpaceShip> temp = new PriorityQueue<SpaceShip>(ships);
		SpaceShip ss=null;
		List<SpaceShip> result = new ArrayList<SpaceShip>(ships.size());
		while((ss=temp.poll())!=null){
			result.add(0, ss);
		}
		return result;
	}
	
	public int sumPower() {
		int sum=0;
		for(SpaceShip ss: ships) {
			sum+=ss.getPower();
		}
		return sum;
	}
	
	public int headCount() {
		return ships.size();
	}
	
	public boolean belongsHere(SpaceShip ss) {
		return ships.contains(ss);
	}
}
