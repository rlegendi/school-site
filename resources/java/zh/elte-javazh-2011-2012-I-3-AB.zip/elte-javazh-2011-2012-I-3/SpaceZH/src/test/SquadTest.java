package test;

import java.util.List;

import zh.SpaceShip;
import zh.Squad;

public class SquadTest implements Test {

	@Override
	public boolean test() {
		boolean isRight = true;
		Squad squad = new Squad();

		if (squad.sumPower() != 0) {
			System.err.println("Az �res raj sumPower()-je legyen 0!");
			isRight = false;
		}

		if (squad.headCount() != 0) {
			System.err.println("Az �res raj headCount()-ja legyen 0!");
			isRight = false;
		}

		SpaceShip enterprise = new SpaceShip("Enterprise", 10);
		SpaceShip defiant = new SpaceShip("Defiant", 20);
		SpaceShip voyager = new SpaceShip("Voyager", 5);
		SpaceShip tieFighter = new SpaceShip("TieFighter", 1);

		squad.add(enterprise);

		if (!squad.belongsHere(enterprise)) {
			System.err.println("Rossz a belongsHere(SpaceShip)");
			System.err.println("Egy hajot nem ismert fel!");
			isRight = false;
		}

		if (squad.belongsHere(defiant)) {
			System.err.println("Rossz a belongshere(SpaceShip)");
			System.err.println("Egy hajot hibasan ismert fel");
			isRight = false;
		}

		squad.add(tieFighter);
		squad.remove(tieFighter);

		if (squad.belongsHere(tieFighter)) {
			System.err.println("Rossz a belongshere(SpaceShip)");
			System.err.println("Egy hajot hibasan ismert fel");
			System.err.println("Vagy rossz a remove(SpaceShip)");
			isRight = false;
		}

		if (squad.sumPower() == 11) {
			System.err.println("Rossz a sumPower() vagy a remove()");
			System.err.println("Elvart: 10");
			System.err.println("Kapott: " + squad.sumPower());
			isRight = false;
		}

		if (squad.headCount() == 2) {
			System.err.println("Rossz a headCount() vagy a remove()");
			System.err.println("Elvart: 1");
			System.err.println("Kapott: " + squad.headCount());
			isRight = false;
		}

		squad.add(voyager);
		squad.add(defiant);

		List<SpaceShip> ships = squad.getList();

		if (ships.size() != 3) {
			System.err.println("A visszaadott lista nem megfelelo elemszamu.");
			System.err.println("Elvart: 3");
			System.err.println("Kapott: " + ships.size());
			isRight = false;
		}

		if (!(ships.contains(enterprise)) || !(ships.contains(voyager))
				|| !(ships.contains(defiant)) || (ships.contains(tieFighter))) {
			System.err
					.println("A vissazdott lista nem a megfelelo elemeket tartalmazza!");
			isRight = false;
		}

		if (!(ships.get(0).equals(defiant))) {
			System.err.println("Rossz a hajok sorrendje, rossz az elso elem!");
			isRight = false;
		}

		if (!(ships.get(1).equals(enterprise))) {
			System.err
					.println("Rossz a hajok sorrendje, rossz a masodik elem!");
			isRight = false;
		}

		if (!(ships.get(2).equals(voyager))) {
			System.err
					.println("Rossz a hajok sorrendje, rossz a harmadik elem!");
			isRight = false;
		}

		return isRight;
	}

}
