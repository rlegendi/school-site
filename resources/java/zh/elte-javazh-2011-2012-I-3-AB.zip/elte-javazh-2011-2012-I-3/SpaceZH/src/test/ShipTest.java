package test;

import java.util.ArrayList;

import zh.SpaceShip;

public class ShipTest implements Test {

	@Override
	public boolean test() {
		boolean isRight = true;

		SpaceShip ship = new SpaceShip("Enterprise", 10);

		if (!ship.getName().equals("Enterprise")) {
			System.err.println("A konstruktor, vagy a getName() rossz");
			System.err.println("Elvart: Enterprise");
			System.err.println("Kapott: " + ship.getName());
			isRight = false;
		}

		if (ship.getPower() != 10) {
			System.err.println("A konstruktor, vagy a getPower() rossz");
			System.err.println("Elvart: 10");
			System.err.println("Kapott: " + ship.getPower());
			isRight = false;
		}

		try {
			if (ship.equals(null)) {
				System.err.println("Rossz az equals()");
				System.err.println("null nem lehet egyenlo");
				isRight = false;
			}
		} catch (NullPointerException npe) {
			System.err
					.println("Az equals() mindig null vizsgalattal kezdodik!");
			isRight = false;
		}

		try {
			if (ship.equals(new Integer(126)) || ship.equals(new Boolean(true))
					|| ship.equals(new ArrayList<Integer>())) {
				System.err.println("Rossz az equals!");
				System.err
						.println("Hogy lenne egy hajo egyenlo valamivel, ami nem hajo?!");
				isRight = false;
			}
		} catch (ClassCastException cce) {
			if (ship.equals(new Integer(126))) {
				System.err.println("Rossz az equals!");
				System.err.println("Tipusellenorzessel mi lesz?");
				isRight = false;
			}
		}

		SpaceShip voyager = new SpaceShip("Voyager", 5);
		SpaceShip hugeVoyager = new SpaceShip("Voyager", 10);
		SpaceShip smallEnterprise = new SpaceShip("Enterprise", 5);
		SpaceShip stabdardEnterprise = new SpaceShip("Enterprise", 10);
		SpaceShip superEnterprise = new SpaceShip("Enterprise", 15);

		SpaceShip ss = voyager;
		if (ship.equals(ss)) {
			System.err.println("Rossz az equals()");
			System.err.println("Egyik ertek: " + ship.getName() + "{"
					+ ship.getPower() + "}");
			System.err.println("Masik ertek: " + ss.getName() + "{"
					+ ss.getPower() + "}");
			isRight = false;
		}

		ss = smallEnterprise;
		if (ship.equals(ss)) {
			System.err.println("Rossz az equals()");
			System.err.println("Egyik ertek: " + ship.getName() + "{"
					+ ship.getPower() + "}");
			System.err.println("Masik ertek: " + ss.getName() + "{"
					+ ss.getPower() + "}");
			isRight = false;
		}

		ss = hugeVoyager;
		if (ship.equals(ss)) {
			System.err.println("Rossz az equals()");
			System.err.println("Egyik ertek: " + ship.getName() + "{"
					+ ship.getPower() + "}");
			System.err.println("Masik ertek: " + ss.getName() + "{"
					+ ss.getPower() + "}");
			isRight = false;
		}

		ss = stabdardEnterprise;
		if (!ship.equals(ss)) {
			System.err.println("Rossz az equals()");
			System.err.println("Egyik ertek: " + ship.getName() + "{"
					+ ship.getPower() + "}");
			System.err.println("Masik ertek: " + ss.getName() + "{"
					+ ss.getPower() + "}");
			isRight = false;
		}

		ss = hugeVoyager;
		if (!(ship.compareTo(ss) == 0)) {
			System.err.println("Rossz a compareTo()");
			System.err.println("Egyik tuzero: " + ship.getPower()
					+ "\tMasik tuzero: " + ss.getPower());
			System.err.println("A compareTo elvart erteke: 0");
			isRight = false;
		}

		ss = smallEnterprise;
		if (!(ship.compareTo(ss) == 1)) {
			System.err.println("Rossz a compareTo()");
			System.err.println("Egyik tuzero: " + ship.getPower()
					+ "\tMasik tuzero: " + ss.getPower());
			System.err.println("A compareTo elvart erteke: 1");
			isRight = false;
		}

		ss = superEnterprise;
		if (!(ship.compareTo(ss) == -1)) {
			System.err.println("Rossz a compareTo()");
			System.err.println("Egyik tuzero: " + ship.getPower()
					+ "\tMasik tuzero: " + ss.getPower());
			System.err.println("A compareTo elvart erteke: -1");
			isRight = false;
		}

		ship.improve(5);
		if (ship.getPower() != 15) {
			System.err.println("Rossz az improve(int) metodus");
			System.err.println("Elvart eredmeny: 15");
			System.err.println("Kapott eredmeny: " + ship.getPower());
			isRight = false;
		}

		return isRight;
	}

}
