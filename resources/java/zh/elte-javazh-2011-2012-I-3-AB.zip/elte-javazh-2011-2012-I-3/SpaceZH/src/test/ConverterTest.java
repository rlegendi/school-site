package test;

import zh.Converter;
import zh.SpaceShip;

public class ConverterTest implements Test {

	@Override
	public boolean test() {
		boolean isRight=true;
		
		String str="Enterprise:10";
		SpaceShip ss=new SpaceShip("Enterprise", 10);
		String toString=Converter.shipToString(ss);
		if(!(toString.equals(str))) {
			System.err.println("Rossz a shipToString(SpaceShip)");
			System.err.println("Elvart: "+str);
			System.err.println("Kapott: "+toString);
			isRight=false;
		}
		
		try{
			String wrongString="";
			Converter.stringToShip(wrongString);
			System.err.println("Ures Stringre a stringToShip(String) dobjon IllegalArgumentException-t");
			System.err.println("Kapott String: "+wrongString);
			isRight=false;
		} catch (IllegalArgumentException iae) {
			
		}
		
		try{
			String wrongString="Enterprise:10:rossz";
			Converter.stringToShip(wrongString);
			System.err.println("Rosszul formalt Stringre a stringToShip(String) dobjon IllegalArgumentException-t");
			System.err.println("Kapott String: "+wrongString);
			isRight=false;
		} catch (IllegalArgumentException iae) {
			
		}
		
		try{
			String wrongString="Enterprise:";
			Converter.stringToShip(wrongString);
			System.err.println("Ha a tuzero nem szam a stringToShip(String) dobjon IllegalArgumentException-t");
			System.err.println("Kapott String: "+wrongString);
			isRight=false;
		} catch (IllegalArgumentException iae) {
			
		}
		
		try{
			String wrongString="Enterprise:0";
			Converter.stringToShip(wrongString);
			System.err.println("1-nel kissebb tuzerore a stringToShip(String) dobjon IllegalArgumentException-t");
			System.err.println("Kapott String: "+wrongString);
			isRight=false;
		} catch (IllegalArgumentException iae) {
			
		}
		
		try{
			String wrongString="Enterprise:tiz";
			Converter.stringToShip(wrongString);
			System.err.println("Ha tuzero nem szam a stringToShip(String) dobjon IllegalArgumentException-t");
			System.err.println("Kapott String: "+wrongString);
			isRight=false;
		} catch (IllegalArgumentException iae) {
			
		}
		
		ss = Converter.stringToShip(str);
		
		if(!(ss.getName().equals("Enterprise"))){
			System.err.println("Roszul olvassa ki a stringToShip(String) a hajo nevet");
			System.err.println("Elvart: Enterprise");
			System.err.println("Kapott: "+ss.getName());
			isRight=false;
		}
		
		if(ss.getPower()!=10) {
			System.err.println("Roszul olvassa ki a stringToShip(String) a hajo tuzerejet");
			System.err.println("Elvart: 10");
			System.err.println("Kapott: "+ss.getPower());
			isRight=false;
		}
		
		return isRight;
	}

}
