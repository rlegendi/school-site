import java.util.ArrayList;
import java.util.List;

import test.ConverterTest;
import test.IOTest;
import test.ShipTest;
import test.SquadTest;
import test.Test;

public class SpaceTest {

	public static void main(String[] args) {
		List<Test> tests = new ArrayList<Test>();
		tests.add(new ShipTest());
		tests.add(new SquadTest());
		tests.add(new ConverterTest());
		tests.add(new IOTest());
		int mark = 1;
		for (Test test : tests) {
			if (test.test()) {
				++mark;
			}
		}
		System.out.println("A jegyed ennel biztosan nem tobb: " + mark);
		System.out.println("De azt soha senki sem mondta, hogy egyenlo is ezzel!");
	}

}
