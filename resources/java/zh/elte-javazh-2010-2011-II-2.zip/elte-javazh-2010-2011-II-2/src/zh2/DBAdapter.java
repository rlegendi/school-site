package zh2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLTransientConnectionException;
import java.sql.Statement;
import java.util.Properties;

public class DBAdapter{
	//==========================================================================
    //members
    protected String CREATE_TABLE = "create table ";
    protected String INSERT_INTO  = "insert into ";
    protected String VALUES       = " values ";
    protected String SELECT       = "select ";
    protected String FROM         = " from ";
    protected String WHERE        = " where ";
    protected String AND          = " and ";
    protected String ORDER_BY     = " order by ";
    protected String DROP_TABLE   = "drop table ";
    protected String UPDATE       = "update ";
    protected String SET          = " set ";
    
    protected String framework = "embedded";
    protected String driver = "org.apache.derby.jdbc.EmbeddedDriver";
    protected String protocol = "jdbc:derby:";
    
    protected Properties props = new Properties();
    protected Connection conn = null;
    
    protected String dbName = "db";
    
    protected boolean connected = false;
    
    //==========================================================================
    //constructors
    public DBAdapter(){
    }
    
    //==========================================================================
    //public functions    
    public void update( String tableName, String[] attrs, String[] values,
                        String[] conditions )
                    throws IllegalArgumentException{
        if( tableName == null || tableName.length() == 0 )
            throw new IllegalArgumentException( "tablename is null or empty!" );
        if( attrs == null || attrs.length == 0 )
            throw new IllegalArgumentException( "attrs[] is empty!" );
        if( values == null || values.length == 0 )
            throw new IllegalArgumentException( "values[] is empty!" );
        if( attrs.length != values.length )
            throw new IllegalArgumentException( "values.length != attrs.length!" );
        
        try{
            Statement s = conn.createStatement();
            
            String command = UPDATE + tableName + SET;
            
            for( int i = 0; i < attrs.length; ++i ){
                if( i > 0 ) command += ", ";
                command += attrs[i] + "=" + values[i];
            }
            
            if( conditions != null && conditions.length != 0 ){
                command += WHERE;
                
                for( int i = 0; i < conditions.length; ++i ){
                    if( i > 0 ) command += AND;
                    command += conditions[i];
                }
            }
            
            s.execute( command );
            
            System.out.println( command );
            
            s.close();
        }catch (Throwable e){
            System.out.println("exception thrown:");

            if (e instanceof SQLException){
                printSQLError((SQLException) e);
            }else{
                e.printStackTrace();
            }
        }
    }
    
    public void connect( String db, boolean createIfNotExist ){
        //org.apache.derby.jdbc.EmbeddedSimpleDataSource ds = null;
        dbName = db;
    	
        try{
            Class.forName(driver).newInstance();
            System.out.println("A megfelelo driver betoltesre kerult.");
            
            String connectionString = protocol + dbName;
            if( createIfNotExist ) connectionString += ";create=true";
            
            conn = DriverManager.getConnection( connectionString, props);
            
            conn.setAutoCommit(false);
            
            connected = true;
        }catch (Throwable e){
            System.out.println("kivetel:");

            if (e instanceof SQLException){
                printSQLError((SQLException) e);
            }else{
                e.printStackTrace();
            }
        }
    }
    
    public void disconnect(){        
        try{
            closeConnection();
            DriverManager.getConnection("jdbc:derby:" + dbName + ";shutdown=true");
            
            connected = false;
        }catch( SQLTransientConnectionException e ){
        	
        }catch (Throwable e){
            System.out.println("kivetel:");

            if (e instanceof SQLException){
                printSQLError((SQLException) e);
            }else{
                e.printStackTrace();
            }
        }
    }
    
    public void commit(){
        try{
            conn.commit();
        }catch (Throwable e){
            System.out.println("kivetel:");

            if (e instanceof SQLException){
                printSQLError((SQLException) e);
            }else{
                e.printStackTrace();
            }
        }
    }
    
    public boolean isConnected(){
        return connected;
    }
    
    public String getDBName(){
        return dbName;
    }
    //==========================================================================
    //private & protected functions
    
    protected void closeConnection(){
        try{
            conn.commit();
            conn.close();
        }catch (Throwable e){
            System.out.println("kivetel:");

            if (e instanceof SQLException){
                printSQLError((SQLException) e);
            }else{
                e.printStackTrace();
            }
        }
    }
    
    protected static void printSQLError(SQLException e)
    {
        while (e != null)
        {
            System.out.println(e.toString());
            e = e.getNextException();
        }
    }
}
