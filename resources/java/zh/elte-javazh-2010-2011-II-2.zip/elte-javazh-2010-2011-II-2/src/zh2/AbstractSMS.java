package zh2;

/**
 * A SMS-t reprezentalo osztaly a szokasos getter es setter metodusokkal
 */
public abstract class AbstractSMS {
	
	/**
	 * A leszarmazott osztaly konstruktora is ilzen parametereket varjon,
	 * ne felejtsd el a super(...) hivast
	 * @param phoneNumber tarolni kell a telefonszamot
	 * @param text tarolni kell az SMS szoveget
	 */
	public AbstractSMS( String phoneNumber, String text ) {
	}

	public abstract String getPhoneNumber();

	public abstract void setPhoneNumber(String phoneNumber);

	public abstract String getText();

	public abstract void setText(String text);	
}
