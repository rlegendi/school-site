package zh2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class SMSServer{
	protected static File serverFile = new File( "data.txt" );
	protected static DBAdapter adapter = new DBAdapter();
	protected static ServerSocket socket;
	protected static Socket acceptedClient;
	protected static BufferedReader socketIn;
	protected static PrintWriter socketOut;

	//=========================================================================
	// Main
	public static void main( String[] args ){
	}
	
	//=========================================================================
	// protected & private methods	
	protected static String saveData( String phoneNumber, String text ){
		PrintWriter writer = null;
		
		try{
			writer = new PrintWriter( new FileWriter( serverFile, true ) );
			writer.println( phoneNumber + ";" + text );
		}catch( IOException e ){
			return "Nem sikerult menteni az adatot:\n" + e.getLocalizedMessage();
		}finally{
			if( writer != null ) writer.close();
		}
		
		return null;
	}
}
