package zh2;

import java.util.List;

import zh2.AbstractSMS;

/**
 * Az SMS lista interfesze
 */
public interface ISMSList {
	/**
	 * Hozzaad egy SMS-t a listahoz 
	 * 
	 * @param phoneNumber a kuldo telefonszama
	 * @param message az uzenet
	 */
	public void addSMS( String phoneNumber, String message );
	
	/**
	 * Visszater a lista meretevel
	 * 
	 * @return a listaban tarolt SMS-ek szama
	 */
	public int getSize();
	
	/**
	 * Visszater az adott indexen talalhato SMS-el
	 * 
	 * @param index a lekerdezett SMS indexe
	 * @return az adott indexen talalhato SMS
	 */
	public AbstractSMS getSMSAt( int index );
	
	/**
	 * Visszater a kuldo telefonszama szerint rendezett listaval
	 * 
	 * @return a telefonszam szerint rendezett SMS lista
	 */
	public List<? extends AbstractSMS> getSMSsInOrderedBySender();
	
	/**
	 * Visszater az SMS szovege szerint rendezett listaval
	 * 
	 * @return az SMS szovege szerint rendezett SMS lista
	 */
	public List<? extends AbstractSMS> getSMSsInOrderOfText();
}
